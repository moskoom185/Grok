//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dw7J_mDJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DslxXnU2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DslxXnU2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-2pSc6DT-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
