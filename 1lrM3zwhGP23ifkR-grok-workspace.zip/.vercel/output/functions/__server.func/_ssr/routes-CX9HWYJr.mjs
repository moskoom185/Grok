import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Copy, E as ArrowLeft, S as Download, T as ChevronDown, _ as ListOrdered, a as TriangleAlert, b as ImagePlus, c as SquareCheckBig, d as Redo2, f as Printer, g as Lock, h as PanelRight, i as Type, l as Sparkles, m as PenLine, n as ZoomOut, o as Trash2, p as Plus, r as Undo2, s as Square, t as ZoomIn, u as Shapes, v as LayoutTemplate, w as ChevronUp, x as FilePlus, y as Image } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as html2canvas } from "../_libs/html2canvas.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CX9HWYJr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
function Button({ className, variant = "ghost", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition disabled:opacity-40", variant === "ghost" && "border border-border bg-surface text-fg hover:bg-bg", variant === "solid" && "bg-primary text-primary-fg hover:brightness-95", variant === "accent" && "bg-accent text-accent-fg hover:brightness-110", variant === "danger" && "text-danger hover:bg-bg", className),
		...props
	});
}
var FRAMES = [
	{
		id: "plain",
		name: "กระดาษขาว",
		hint: "ไม่มีกรอบ",
		thumb: "#FFFFFF",
		bg: "#FFFFFF"
	},
	{
		id: "wi-teal",
		name: "WI มืออาชีพ",
		hint: "หัวเข้ม มุมโค้ง",
		thumb: "#0E6B66",
		bg: "#F4FAF9"
	},
	{
		id: "factory",
		name: "โรงงานเหลือง",
		hint: "หัวโค้งมน",
		thumb: "#E0A800",
		bg: "#FFFEFA"
	},
	{
		id: "grid12",
		name: "12 ขั้นตอน",
		hint: "กริดการ์ด",
		thumb: "#148C8A",
		bg: "#F2FBFA"
	},
	{
		id: "elegant",
		name: "กรอบหรู",
		hint: "ลายเส้นอ่อน",
		thumb: "#E8D5C4",
		bg: "#FBF6F0"
	},
	{
		id: "wave",
		name: "คลื่นธุรกิจ",
		hint: "โค้งน้ำเงิน",
		thumb: "#1D4E89",
		bg: "#F5F8FC"
	},
	{
		id: "floral",
		name: "ดอกไม้",
		hint: "มุมดอก",
		thumb: "#E8A0A0",
		bg: "#FFFCF8"
	},
	{
		id: "botanical",
		name: "ใบไม้",
		hint: "กรอบเขียว",
		thumb: "#3E6B4F",
		bg: "#F7FBF6"
	},
	{
		id: "memphis",
		name: "เมมฟิส",
		hint: "รูปทรงสีสด",
		thumb: "#F2C14E",
		bg: "#FFFDF7"
	},
	{
		id: "dark",
		name: "ปกเข้ม",
		hint: "หัวดำทอง",
		thumb: "#16120E",
		bg: "#1A1714"
	},
	{
		id: "cyber",
		name: "นีออน",
		hint: "มุมเรืองแสง",
		thumb: "#2A1650",
		bg: "#12081F"
	},
	{
		id: "parchment",
		name: "โบราณ",
		hint: "กระดาษเก่า",
		thumb: "#C9B48A",
		bg: "#F3E6C8"
	},
	{
		id: "school",
		name: "สมุดนักเรียน",
		hint: "ตารางฟ้า",
		thumb: "#7EC8E3",
		bg: "#F4FBFF"
	},
	{
		id: "splash",
		name: "ศิลปะ",
		hint: "สีกระเด็น",
		thumb: "#5B8DEF",
		bg: "#FFFFFF"
	},
	{
		id: "festive",
		name: "เทศกาล",
		hint: "แดงทอง",
		thumb: "#C81E1E",
		bg: "#FFF8F2"
	},
	{
		id: "notebook",
		name: "สมุดปกอ่อน",
		hint: "เส้นบรรทัด",
		thumb: "#F2D0A4",
		bg: "#FFF9EF"
	}
];
function C({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "pointer-events-none absolute inset-0 h-full w-full",
		viewBox: "0 0 210 297",
		preserveAspectRatio: "none",
		"aria-hidden": true,
		children
	});
}
function PageFrame({ id, color }) {
	const k = color;
	switch (id) {
		case "wi-teal": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F4FAF9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 0 H210 V52 Q168 78 120 58 T0 70 Z",
					fill: k
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "198",
					cy: "18",
					r: "28",
					fill: "#ffffff22"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "186",
					cy: "8",
					r: "10",
					fill: "#ffffff18"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "8",
					y: "8",
					width: "194",
					height: "281",
					rx: "10",
					fill: "none",
					stroke: k,
					strokeWidth: "1.2",
					opacity: "0.35"
				})
			]
		});
		case "factory": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFFEFA"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 0 H210 V38 Q105 58 0 38 Z",
					fill: k
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "200",
					cy: "-4",
					r: "36",
					fill: "#ffffff33"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "6",
					y: "6",
					width: "198",
					height: "285",
					rx: "4",
					fill: "none",
					stroke: k,
					strokeWidth: "1.4"
				})
			]
		});
		case "grid12": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F2FBFA"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M210 0 L210 44 L150 0 Z",
					fill: k,
					opacity: "0.9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "12",
					cy: "16",
					r: "10",
					fill: k
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "7",
					y: "7",
					width: "196",
					height: "283",
					rx: "12",
					fill: "none",
					stroke: k,
					strokeWidth: "1.6"
				})
			]
		});
		case "elegant": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FBF6F0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "8",
					y: "8",
					width: "194",
					height: "281",
					fill: "none",
					stroke: k,
					strokeWidth: "0.6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "11",
					y: "11",
					width: "188",
					height: "275",
					fill: "none",
					stroke: k,
					strokeWidth: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20 20 C28 12, 40 12, 48 20",
					fill: "none",
					stroke: k,
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M190 20 C182 12, 170 12, 162 20",
					fill: "none",
					stroke: k,
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M20 277 C28 285, 40 285, 48 277",
					fill: "none",
					stroke: k,
					strokeWidth: "0.7"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M190 277 C182 285, 170 285, 162 277",
					fill: "none",
					stroke: k,
					strokeWidth: "0.7"
				})
			]
		});
		case "wave": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F5F8FC"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 0 H78 C110 40 40 90 0 130 Z",
					fill: k
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M210 297 H132 C100 250 170 210 210 170 Z",
					fill: k,
					opacity: "0.85"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "42",
					cy: "70",
					r: "22",
					fill: "#ffffff33"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "42",
					cy: "70",
					r: "12",
					fill: "#ffffff22"
				})
			]
		});
		case "floral": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFFCF8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					fill: k,
					opacity: "0.55",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "18",
							cy: "22",
							r: "8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "28",
							cy: "16",
							r: "5"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "30",
							cy: "28",
							r: "6"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "192",
							cy: "24",
							r: "9"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "180",
							cy: "16",
							r: "5"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "184",
							cy: "34",
							r: "6"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "20",
							cy: "276",
							r: "8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "32",
							cy: "282",
							r: "5"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "190",
							cy: "274",
							r: "9"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "178",
							cy: "282",
							r: "6"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "14",
					y: "18",
					width: "182",
					height: "261",
					rx: "6",
					fill: "none",
					stroke: k,
					strokeWidth: "0.8",
					opacity: "0.4"
				})
			]
		});
		case "botanical": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F7FBF6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					fill: "none",
					stroke: k,
					strokeWidth: "1.1",
					opacity: "0.7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 40 C30 10, 60 20, 40 50 C20 70, 10 90, 24 110" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M202 250 C180 280, 150 270, 170 240 C188 220, 200 200, 186 180" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "28",
					cy: "58",
					rx: "10",
					ry: "5",
					fill: k,
					opacity: "0.35",
					transform: "rotate(-30 28 58)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "182",
					cy: "232",
					rx: "12",
					ry: "5",
					fill: k,
					opacity: "0.35",
					transform: "rotate(40 182 232)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "10",
					y: "10",
					width: "190",
					height: "277",
					rx: "2",
					fill: "none",
					stroke: k,
					strokeWidth: "1",
					opacity: "0.3"
				})
			]
		});
		case "memphis": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFFDF7"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "18",
					cy: "20",
					r: "16",
					fill: k,
					opacity: "0.85"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "170",
					y: "-8",
					width: "50",
					height: "50",
					rx: "18",
					fill: "#7C5CFC"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M0 250 L40 297 H0 Z",
					fill: "#FF6B9D"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M160 8 Q190 30 170 50",
					fill: "none",
					stroke: "#7C5CFC",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "12",
					y: "16",
					width: "186",
					height: "265",
					fill: "none",
					stroke: "#1A1714",
					strokeWidth: "1.2"
				})
			]
		});
		case "dark": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#1A1714"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "10",
					y: "10",
					width: "190",
					height: "277",
					fill: "none",
					stroke: k,
					strokeWidth: "0.8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "105",
					cy: "40",
					r: "22",
					fill: "none",
					stroke: k,
					strokeWidth: "0.7"
				})
			]
		});
		case "cyber": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#12081F"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "8",
					y: "8",
					width: "194",
					height: "281",
					fill: "none",
					stroke: "#C77DFF",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "12",
					y: "12",
					width: "186",
					height: "273",
					fill: "none",
					stroke: "#7B2CBF",
					strokeWidth: "0.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "18",
					cy: "18",
					r: "3",
					fill: "#E0A800"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "192",
					cy: "18",
					r: "3",
					fill: "#E0A800"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "18",
					cy: "279",
					r: "3",
					fill: "#E0A800"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "192",
					cy: "279",
					r: "3",
					fill: "#E0A800"
				})
			]
		});
		case "parchment": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F3E6C8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "9",
					y: "9",
					width: "192",
					height: "279",
					fill: "none",
					stroke: "#8A6A32",
					strokeWidth: "2.2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "13",
					y: "13",
					width: "184",
					height: "271",
					fill: "none",
					stroke: "#8A6A32",
					strokeWidth: "0.6"
				})
			]
		});
		case "school": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#F4FBFF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "0",
					y: "0",
					width: "210",
					height: "18",
					fill: "#7EC8E3"
				}),
				Array.from({ length: 26 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "16",
					x2: "198",
					y1: 28 + i * 10,
					y2: 28 + i * 10,
					stroke: "#BFE4F2",
					strokeWidth: "0.4"
				}, i)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "28",
					y1: "18",
					x2: "28",
					y2: "290",
					stroke: "#F2A0A0",
					strokeWidth: "0.6"
				})
			]
		});
		case "splash": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFFFFF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "20",
					cy: "16",
					r: "14",
					fill: "#5B8DEF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "38",
					cy: "10",
					r: "8",
					fill: "#FF6B9D"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "190",
					cy: "20",
					r: "12",
					fill: "#F2C14E"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "18",
					cy: "280",
					r: "16",
					fill: "#7C5CFC"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "200",
					cy: "270",
					r: "20",
					fill: "#5B8DEF",
					opacity: "0.7"
				})
			]
		});
		case "festive": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFF8F2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "36",
					fill: "#C81E1E"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					y: "261",
					width: "210",
					height: "36",
					fill: "#C81E1E"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "24",
					cy: "18",
					r: "8",
					fill: "#E0A800"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "186",
					cy: "18",
					r: "8",
					fill: "#E0A800"
				})
			]
		});
		case "notebook": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(C, {
			color: k,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "210",
					height: "297",
					fill: "#FFF9EF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "0",
					y: "0",
					width: "14",
					height: "297",
					fill: "#E8C48A"
				}),
				Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "7",
					cy: 24 + i * 34,
					r: "3.2",
					fill: "#FFF9EF"
				}, i))
			]
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0",
			style: { background: "#fff" }
		});
	}
}
var PAPER = {
	A4: [210, 297],
	A5: [148, 210],
	Letter: [216, 279]
};
function pageSize(paper, ori) {
	const [a, b] = PAPER[paper];
	return ori === "l" ? {
		w: b,
		h: a
	} : {
		w: a,
		h: b
	};
}
var FONTS = [
	"Noto Sans Thai",
	"Sarabun",
	"Prompt",
	"Kanit",
	"Mitr",
	"Playfair Display",
	"Be Vietnam Pro"
];
var PRESET_COLORS = [
	"#0E6B66",
	"#E0A800",
	"#1A1714",
	"#C45C26",
	"#3D5A80",
	"#7B2D8E",
	"#C81E1E",
	"#2E7D4F",
	"#FFFFFF",
	"#F6F0E4",
	"#0B1F3A",
	"#FF6B9D"
];
var KEY = "wi-studio-v1";
function today() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function sampleSteps() {
	return [
		["ตรวจสอบพื้นที่", "ดูความเรียบร้อยและความปลอดภัยก่อนเริ่มงาน"],
		["สวม PPE", "หมวก แว่น ถุงมือ รองเท้าเซฟตี้"],
		["ปิดแหล่งพลังงาน", "Lockout-Tagout ตามขั้นตอน"],
		["ปฏิบัติงาน", "ทำตามคู่มือผู้ผลิตทีละขั้น"]
	].map((t, i) => ({
		id: uid(),
		type: "step",
		x: 12 + i % 2 * 94,
		y: 78 + Math.floor(i / 2) * 72,
		w: 90,
		h: 66,
		z: 10 + i,
		num: i + 1,
		text: t[0],
		desc: t[1],
		time: "5",
		ppl: "1",
		fill: "#ffffff",
		stroke: "#0E6B66",
		radius: 8,
		font: "Noto Sans Thai",
		fontSize: 11,
		color: "#1A1714"
	}));
}
function seedPage(frame, color) {
	const dark = frame === "dark" || frame === "cyber";
	const ink = dark ? "#F6F0E4" : "#1A1714";
	const els = [
		{
			id: uid(),
			type: "text",
			x: 14,
			y: frame === "factory" || frame === "wi-teal" || frame === "festive" ? 8 : 16,
			w: 130,
			h: 22,
			z: 20,
			text: "WORK INSTRUCTION",
			font: "Prompt",
			fontSize: 16,
			fontWeight: 800,
			color: frame === "plain" || frame === "elegant" || frame === "floral" ? color : "#FFFFFF",
			align: "left"
		},
		{
			id: uid(),
			type: "text",
			x: 14,
			y: frame === "factory" || frame === "wi-teal" || frame === "festive" ? 24 : 32,
			w: 130,
			h: 12,
			z: 21,
			text: "คู่มือขั้นตอนการทำงาน",
			font: "Noto Sans Thai",
			fontSize: 9,
			color: frame === "plain" || frame === "elegant" || frame === "floral" ? ink : "#FFFFFFCC"
		},
		{
			id: uid(),
			type: "box",
			x: 12,
			y: 58,
			w: 186,
			h: 16,
			z: 5,
			text: "เลขที่ WI-001  ·  Rev 00  ·  แผนก Engineering",
			fill: dark ? "#ffffff14" : "#ffffff",
			stroke: color,
			radius: 6,
			fontSize: 8,
			color: ink,
			font: "Noto Sans Thai"
		},
		...sampleSteps(),
		{
			id: uid(),
			type: "box",
			x: 12,
			y: 228,
			w: 90,
			h: 36,
			z: 8,
			text: "ข้อควรระวัง",
			desc: "ตัดไฟก่อนซ่อม · ระวังของมีคม",
			fill: "#FFF4E5",
			stroke: "#C45C26",
			radius: 8,
			fontSize: 9,
			fontWeight: 700,
			color: "#8A3B12",
			font: "Noto Sans Thai"
		},
		{
			id: uid(),
			type: "box",
			x: 108,
			y: 228,
			w: 90,
			h: 36,
			z: 8,
			text: "หมายเหตุ",
			desc: "อ้างอิงคู่มือผู้ผลิต",
			fill: "#EAF4FF",
			stroke: "#3D5A80",
			radius: 8,
			fontSize: 9,
			fontWeight: 700,
			color: "#1E3A5F",
			font: "Noto Sans Thai"
		},
		{
			id: uid(),
			type: "signature",
			x: 12,
			y: 268,
			w: 186,
			h: 22,
			z: 9,
			text: "ผู้จัดทำ / ผู้ตรวจสอบ / ผู้อนุมัติ",
			fontSize: 8,
			color: ink,
			font: "Noto Sans Thai",
			fill: dark ? "#ffffff10" : "#ffffff",
			stroke: color,
			radius: 6
		}
	];
	return {
		id: uid(),
		frame,
		bg: dark ? "#1A1714" : "#FFFFFF",
		elements: els
	};
}
function blankDoc() {
	return {
		id: "d_" + uid(),
		title: "งานบำรุงรักษาเครื่องจักร",
		sub: "คู่มือขั้นตอนการทำงาน",
		docNo: "WI-001",
		rev: "00",
		date: today(),
		dept: "Engineering",
		paper: "A4",
		ori: "p",
		color: "#0E6B66",
		pages: [seedPage("wi-teal", "#0E6B66")],
		updated: Date.now()
	};
}
function read() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		return JSON.parse(raw);
	} catch {
		return [];
	}
}
var useStudio = create((set, get) => ({
	docs: [],
	currentId: null,
	pageIndex: 0,
	selected: null,
	editing: null,
	zoom: .85,
	ready: false,
	hist: {
		past: [],
		future: []
	},
	load: () => {
		set({
			docs: read(),
			ready: true
		});
	},
	persist: () => {
		localStorage.setItem(KEY, JSON.stringify(get().docs));
	},
	newDoc: (frame = "wi-teal") => {
		const d = blankDoc();
		if (frame !== "wi-teal") {
			d.pages = [seedPage(frame, d.color)];
			d.pages[0].frame = frame;
		}
		set((s) => ({
			docs: [d, ...s.docs],
			currentId: d.id,
			pageIndex: 0,
			selected: null,
			hist: {
				past: [],
				future: []
			}
		}));
		get().persist();
	},
	openDoc: (id) => set({
		currentId: id,
		pageIndex: 0,
		selected: null,
		hist: {
			past: [],
			future: []
		}
	}),
	deleteDoc: (id) => {
		set((s) => ({
			docs: s.docs.filter((d) => d.id !== id),
			currentId: s.currentId === id ? null : s.currentId
		}));
		get().persist();
	},
	closeDoc: () => set({
		currentId: null,
		selected: null,
		editing: null
	}),
	doc: () => get().docs.find((d) => d.id === get().currentId) ?? null,
	page: () => {
		const d = get().doc();
		if (!d) return null;
		return d.pages[get().pageIndex] ?? d.pages[0] ?? null;
	},
	patchDoc: (p, hist = true) => {
		if (hist) get().snapshot();
		set((s) => ({ docs: s.docs.map((d) => d.id === s.currentId ? {
			...d,
			...p,
			updated: Date.now()
		} : d) }));
		get().persist();
	},
	setFrame: (frame) => {
		get().snapshot();
		set((s) => ({ docs: s.docs.map((d) => {
			if (d.id !== s.currentId) return d;
			const pages = d.pages.map((pg, i) => i === s.pageIndex ? {
				...pg,
				frame
			} : pg);
			return {
				...d,
				pages,
				updated: Date.now()
			};
		}) }));
		get().persist();
	},
	select: (id) => set({
		selected: id,
		editing: id ? get().editing : null
	}),
	setEditing: (id) => set({
		editing: id,
		selected: id ?? get().selected
	}),
	addEl: (partial) => {
		get().snapshot();
		const id = uid();
		const el = {
			x: 20,
			y: 40,
			w: 60,
			h: 24,
			z: (get().page()?.elements.reduce((m, e) => Math.max(m, e.z), 0) ?? 1) + 1,
			font: FONTS[0],
			fontSize: 12,
			color: "#1A1714",
			fill: "#ffffff",
			...partial,
			id,
			type: partial.type
		};
		set((s) => ({
			docs: s.docs.map((d) => {
				if (d.id !== s.currentId) return d;
				const pages = d.pages.map((pg, i) => i === s.pageIndex ? {
					...pg,
					elements: [...pg.elements, el]
				} : pg);
				return {
					...d,
					pages,
					updated: Date.now()
				};
			}),
			selected: id
		}));
		get().persist();
		return id;
	},
	updateEl: (id, p, hist = false) => {
		if (hist) get().snapshot();
		set((s) => ({ docs: s.docs.map((d) => {
			if (d.id !== s.currentId) return d;
			const pages = d.pages.map((pg, i) => i === s.pageIndex ? {
				...pg,
				elements: pg.elements.map((e) => e.id === id ? {
					...e,
					...p
				} : e)
			} : pg);
			return {
				...d,
				pages,
				updated: Date.now()
			};
		}) }));
		get().persist();
	},
	removeEl: (id) => {
		get().snapshot();
		set((s) => ({
			selected: s.selected === id ? null : s.selected,
			editing: s.editing === id ? null : s.editing,
			docs: s.docs.map((d) => {
				if (d.id !== s.currentId) return d;
				const pages = d.pages.map((pg, i) => i === s.pageIndex ? {
					...pg,
					elements: pg.elements.filter((e) => e.id !== id)
				} : pg);
				return {
					...d,
					pages,
					updated: Date.now()
				};
			})
		}));
		get().persist();
	},
	duplicateEl: (id) => {
		const el = get().page()?.elements.find((e) => e.id === id);
		if (!el) return;
		const { id: _omit, ...rest } = el;
		get().addEl({
			...rest,
			x: el.x + 6,
			y: el.y + 6
		});
	},
	bring: (id, dir) => {
		get().snapshot();
		set((s) => ({ docs: s.docs.map((d) => {
			if (d.id !== s.currentId) return d;
			const pages = d.pages.map((pg, i) => {
				if (i !== s.pageIndex) return pg;
				const zs = pg.elements.map((e) => e.z);
				const max = Math.max(...zs);
				const min = Math.min(...zs);
				return {
					...pg,
					elements: pg.elements.map((e) => e.id === id ? {
						...e,
						z: dir === "front" ? max + 1 : min - 1
					} : e)
				};
			});
			return {
				...d,
				pages
			};
		}) }));
		get().persist();
	},
	snapshot: () => {
		const d = get().doc();
		if (!d) return;
		set((s) => ({ hist: {
			past: [...s.hist.past.slice(-40), JSON.stringify(d)],
			future: []
		} }));
	},
	undo: () => {
		const { hist, currentId } = get();
		if (!hist.past.length || !currentId) return;
		const prev = hist.past[hist.past.length - 1];
		const cur = JSON.stringify(get().doc());
		const doc = JSON.parse(prev);
		set((s) => ({
			hist: {
				past: s.hist.past.slice(0, -1),
				future: [...s.hist.future, cur]
			},
			docs: s.docs.map((d) => d.id === currentId ? doc : d)
		}));
		get().persist();
	},
	redo: () => {
		const { hist, currentId } = get();
		if (!hist.future.length || !currentId) return;
		const next = hist.future[hist.future.length - 1];
		const cur = JSON.stringify(get().doc());
		const doc = JSON.parse(next);
		set((s) => ({
			hist: {
				past: [...s.hist.past, cur],
				future: s.hist.future.slice(0, -1)
			},
			docs: s.docs.map((d) => d.id === currentId ? doc : d)
		}));
		get().persist();
	},
	addPage: () => {
		const d = get().doc();
		if (!d) return;
		get().snapshot();
		const pg = seedPage(d.pages[0]?.frame ?? "plain", d.color);
		set((s) => ({
			pageIndex: d.pages.length,
			docs: s.docs.map((x) => x.id === d.id ? {
				...x,
				pages: [...x.pages, pg],
				updated: Date.now()
			} : x)
		}));
		get().persist();
	},
	setPage: (i) => set({
		pageIndex: i,
		selected: null,
		editing: null
	}),
	setZoom: (z) => set({ zoom: Math.min(1.8, Math.max(.35, z)) })
}));
function defaultEl(type, extra) {
	return {
		type,
		...{
			text: {
				w: 80,
				h: 16,
				text: "พิมพ์ข้อความ",
				fontSize: 12
			},
			image: {
				w: 70,
				h: 50,
				fill: "#F3ECE0"
			},
			shape: {
				w: 40,
				h: 40,
				fill: "#0E6B66",
				shape: "round"
			},
			icon: {
				w: 16,
				h: 16,
				icon: "star",
				color: "#E0A800"
			},
			step: {
				w: 90,
				h: 64,
				text: "ขั้นตอนใหม่",
				desc: "รายละเอียด…",
				num: 1,
				time: "5",
				ppl: "1",
				stroke: "#0E6B66",
				radius: 8
			},
			box: {
				w: 90,
				h: 32,
				text: "หัวข้อกล่อง",
				desc: "เนื้อหา",
				fill: "#FFF4E5",
				stroke: "#C45C26",
				radius: 8
			},
			line: {
				w: 80,
				h: 2,
				fill: "#1A1714"
			},
			sticker: {
				w: 22,
				h: 22,
				sticker: "star",
				color: "#E0A800"
			},
			signature: {
				w: 186,
				h: 22,
				text: "ผู้จัดทำ / วันที่",
				stroke: "#0E6B66"
			},
			checklist: {
				w: 90,
				h: 40,
				text: "ตรวจก่อนเริ่มงาน",
				items: [
					"ข้อ 1",
					"ข้อ 2",
					"ข้อ 3"
				],
				stroke: "#0E6B66",
				radius: 8
			}
		}[type] ?? {},
		...extra
	};
}
function Dashboard() {
	const { docs, newDoc, openDoc, deleteDoc } = useStudio();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full overflow-y-auto bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-6 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-widest text-accent uppercase",
							children: "WI Studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-3xl font-extrabold",
							children: "สร้างคู่มืองานแบบลากวาง"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: "จิ้มบนหน้ากระดาษแล้วพิมพ์ได้เลย เลือกกรอบเทมเพลต ใส่รูป ตกแต่ง และส่งออก — เหมือน Canva สำหรับ Work Instruction"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "solid",
						onClick: () => newDoc("wi-teal"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlus, { className: "size-4" }), " สร้างใหม่"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-extrabold",
					children: "เริ่มจากเทมเพลต"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-10 grid grid-cols-2 gap-3 sm:grid-cols-4",
					children: FRAMES.slice(0, 8).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => newDoc(f.id),
						className: "overflow-hidden rounded-2xl border border-border bg-surface text-left hover:border-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-20",
							style: { background: f.thumb }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: f.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted",
								children: f.hint
							})]
						})]
					}, f.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-extrabold",
					children: "เอกสารของฉัน"
				}),
				docs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "ยังไม่มีเอกสาร — กดสร้างใหม่หรือเลือกเทมเพลตด้านบน"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: docs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex cursor-pointer flex-col rounded-2xl border border-border bg-surface p-4 hover:border-primary",
						onClick: () => openDoc(d.id),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-bg px-2 py-0.5 text-[11px] font-bold",
									children: d.docNo
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "text-muted hover:text-danger",
									onClick: (e) => {
										e.stopPropagation();
										if (confirm("ลบเอกสารนี้?")) deleteDoc(d.id);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-bold",
								children: d.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									d.pages.length,
									" หน้า · ",
									new Date(d.updated).toLocaleString("th-TH")
								]
							})
						]
					}, d.id))
				})
			]
		})
	});
}
var STICKERS = [
	{
		id: "star",
		name: "ดาว",
		svg: `<svg viewBox="0 0 64 64"><polygon fill="currentColor" points="32,4 40,24 62,24 44,38 52,58 32,46 12,58 20,38 2,24 24,24"/></svg>`
	},
	{
		id: "heart",
		name: "หัวใจ",
		svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M32 56s-24-14-24-30a14 14 0 0 1 24-10 14 14 0 0 1 24 10c0 16-24 30-24 30z"/></svg>`
	},
	{
		id: "leaf",
		name: "ใบไม้",
		svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M12 52 C12 20 44 8 56 8 56 28 40 56 12 52Z"/><path fill="none" stroke="#fff" stroke-width="2" d="M20 44 C28 32 40 20 52 14"/></svg>`
	},
	{
		id: "flower",
		name: "ดอกไม้",
		svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="18" r="10" fill="currentColor"/><circle cx="18" cy="28" r="10" fill="currentColor"/><circle cx="46" cy="28" r="10" fill="currentColor"/><circle cx="22" cy="46" r="10" fill="currentColor"/><circle cx="42" cy="46" r="10" fill="currentColor"/><circle cx="32" cy="32" r="8" fill="#F2C14E"/></svg>`
	},
	{
		id: "badge",
		name: "ป้าย",
		svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="currentColor"/><circle cx="32" cy="32" r="20" fill="none" stroke="#fff" stroke-width="2"/></svg>`
	},
	{
		id: "warn",
		name: "ระวัง",
		svg: `<svg viewBox="0 0 64 64"><polygon fill="#E0A800" points="32,6 60,56 4,56"/><rect x="29" y="24" width="6" height="18" fill="#1A1714"/><rect x="29" y="46" width="6" height="6" fill="#1A1714"/></svg>`
	},
	{
		id: "check",
		name: "ถูก",
		svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="#2E7D4F"/><path d="M18 33 l10 10 18-20" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/></svg>`
	},
	{
		id: "gear",
		name: "เฟือง",
		svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="12" fill="none" stroke="currentColor" stroke-width="6"/><g fill="currentColor">${[
			0,
			45,
			90,
			135,
			180,
			225,
			270,
			315
		].map((a) => `<rect x="29" y="2" width="6" height="14" transform="rotate(${a} 32 32)"/>`).join("")}</g></svg>`
	},
	{
		id: "clip",
		name: "คลิปบอร์ด",
		svg: `<svg viewBox="0 0 64 64"><rect x="12" y="10" width="40" height="48" rx="4" fill="currentColor"/><rect x="18" y="18" width="28" height="6" fill="#fff"/><rect x="18" y="28" width="28" height="4" fill="#fff" opacity=".7"/><rect x="18" y="36" width="20" height="4" fill="#fff" opacity=".7"/></svg>`
	},
	{
		id: "tape",
		name: "เทป",
		svg: `<svg viewBox="0 0 64 24"><rect x="0" y="4" width="64" height="16" fill="currentColor" opacity=".75" transform="rotate(-8 32 12)"/></svg>`
	},
	{
		id: "arrow",
		name: "ลูกศร",
		svg: `<svg viewBox="0 0 64 64"><path d="M8 32 H44 L32 20 M44 32 L32 44" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>`
	},
	{
		id: "spark",
		name: "ประกาย",
		svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M32 2 L36 24 L58 28 L36 32 L32 54 L28 32 L6 28 L28 24 Z"/></svg>`
	},
	{
		id: "cloud",
		name: "เมฆ",
		svg: `<svg viewBox="0 0 64 40"><ellipse cx="24" cy="24" rx="16" ry="12" fill="currentColor"/><ellipse cx="40" cy="22" rx="14" ry="12" fill="currentColor"/><ellipse cx="32" cy="16" rx="12" ry="10" fill="currentColor"/></svg>`
	},
	{
		id: "pin",
		name: "หมุด",
		svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="20" r="14" fill="currentColor"/><rect x="29" y="32" width="6" height="26" fill="currentColor"/></svg>`
	},
	{
		id: "dotgrid",
		name: "จุด",
		svg: `<svg viewBox="0 0 40 40">${[
			8,
			20,
			32
		].flatMap((x) => [
			8,
			20,
			32
		].map((y) => `<circle cx="${x}" cy="${y}" r="3" fill="currentColor"/>`)).join("")}</svg>`
	}
];
function ElementView({ el, editing, onChangeText }) {
	const font = {
		fontFamily: el.font ?? "Noto Sans Thai",
		fontSize: `${el.fontSize ?? 11}px`,
		fontWeight: el.fontWeight ?? 500,
		color: el.color ?? "#1A1714",
		textAlign: el.align ?? "left",
		opacity: el.opacity ?? 1
	};
	const edit = (field) => editing ? {
		contentEditable: true,
		suppressContentEditableWarning: true,
		onBlur: (e) => onChangeText({ [field]: e.currentTarget.innerText }),
		className: "outline-none min-w-[1ch]"
	} : {};
	if (el.type === "line") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full w-full",
		style: {
			background: el.fill ?? "#1A1714",
			borderRadius: 2
		}
	});
	if (el.type === "shape") {
		const r = el.shape === "round" ? "999px" : el.shape === "ellipse" ? "50%" : `${el.radius ?? 8}px`;
		if (el.shape === "triangle") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full",
			style: {
				clipPath: "polygon(50% 0, 100% 100%, 0 100%)",
				background: el.fill ?? "#0E6B66",
				opacity: el.opacity ?? 1
			}
		});
		if (el.shape === "diamond") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full",
			style: {
				clipPath: "polygon(50% 0, 100% 50%, 50% 100%, 0 50%)",
				background: el.fill ?? "#0E6B66",
				opacity: el.opacity ?? 1
			}
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full",
			style: {
				background: el.fill,
				border: el.stroke ? `${el.strokeW ?? 1}px solid ${el.stroke}` : void 0,
				borderRadius: r,
				opacity: el.opacity ?? 1
			}
		});
	}
	if (el.type === "sticker") {
		const s = STICKERS.find((x) => x.id === el.sticker) ?? STICKERS[0];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full [&_svg]:h-full [&_svg]:w-full",
			style: { color: el.color ?? "#E0A800" },
			dangerouslySetInnerHTML: { __html: s.svg }
		});
	}
	if (el.type === "image") return el.src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: el.src,
		alt: "",
		className: "h-full w-full object-cover",
		draggable: false
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full w-full items-center justify-center bg-bg text-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-8" })
	});
	if (el.type === "step") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full w-full flex-col overflow-hidden",
		style: {
			background: el.fill ?? "#fff",
			border: `1.4px solid ${el.stroke ?? "#0E6B66"}`,
			borderRadius: el.radius ?? 8
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-1.5 px-1.5 pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-extrabold text-accent-fg",
					style: { background: el.stroke ?? "#0E6B66" },
					children: el.num ?? 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						...edit("text"),
						style: {
							...font,
							fontWeight: 800,
							fontSize: 11
						},
						children: el.text
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						...edit("desc"),
						style: {
							...font,
							fontWeight: 400,
							fontSize: 9,
							opacity: .85
						},
						children: el.desc
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-1.5 mt-1 min-h-0 flex-1 overflow-hidden rounded bg-bg",
				children: el.src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: el.src,
					alt: "",
					className: "h-full w-full object-cover",
					draggable: false
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-5" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2 px-1.5 py-0.5 text-[8px] text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [el.time ?? "5", " นาที"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [el.ppl ?? "1", " คน"] })]
			})
		]
	});
	if (el.type === "box" || el.type === "signature" || el.type === "checklist") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full w-full flex-col overflow-hidden px-2 py-1",
		style: {
			background: el.fill ?? "#fff",
			border: `1.2px solid ${el.stroke ?? "#E5D9C4"}`,
			borderRadius: el.radius ?? 8,
			...font
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			...edit("text"),
			style: { fontWeight: 800 },
			children: el.text
		}), el.type === "checklist" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-0.5 space-y-0.5 text-[9px] font-normal",
			children: (el.items ?? []).map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-2 rounded-sm border border-current" }), it]
			}, i))
		}) : el.desc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			...edit("desc"),
			className: "text-[9px] font-normal opacity-80",
			children: el.desc
		}) : el.type === "signature" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 flex flex-1 gap-2",
			children: [
				"ผู้จัดทำ",
				"ผู้ตรวจ",
				"ผู้อนุมัติ"
			].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 border-b border-dashed border-muted text-center text-[8px]",
				children: l
			}, l))
		}) : null]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		...edit("text"),
		className: cn("h-full w-full leading-tight", editing && "ring-0"),
		style: font,
		children: el.text
	});
}
function Canvas() {
	const store = useStudio();
	const doc = store.doc();
	const page = store.page();
	const wrap = (0, import_react.useRef)(null);
	const [drag, setDrag] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const onMove = (e) => {
			if (!drag || !doc) return;
			const size = pageSize(doc.paper, doc.ori);
			const pageEl = wrap.current?.querySelector("[data-page]");
			if (!pageEl) return;
			const r = pageEl.getBoundingClientRect();
			const mmX = (e.clientX - r.left) / r.width * size.w;
			const mmY = (e.clientY - r.top) / r.height * size.h;
			const dx = mmX - drag.sx;
			const dy = mmY - drag.sy;
			if (drag.mode === "move") store.updateEl(drag.id, {
				x: Math.round((drag.ox + dx) * 10) / 10,
				y: Math.round((drag.oy + dy) * 10) / 10
			});
			else store.updateEl(drag.id, {
				w: Math.max(8, Math.round((drag.ow + dx) * 10) / 10),
				h: Math.max(6, Math.round((drag.oh + dy) * 10) / 10)
			});
		};
		const onUp = () => setDrag(null);
		window.addEventListener("pointermove", onMove);
		window.addEventListener("pointerup", onUp);
		return () => {
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerup", onUp);
		};
	}, [
		drag,
		doc,
		store
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const t = e.target;
			if (t.isContentEditable || t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
			if ((e.metaKey || e.ctrlKey) && e.key === "z") {
				e.preventDefault();
				e.shiftKey ? store.redo() : store.undo();
			}
			if ((e.metaKey || e.ctrlKey) && e.key === "d" && store.selected) {
				e.preventDefault();
				store.duplicateEl(store.selected);
			}
			if ((e.key === "Delete" || e.key === "Backspace") && store.selected && !store.editing) store.removeEl(store.selected);
			if (e.key === "Escape") {
				store.setEditing(null);
				store.select(null);
			}
			if (e.key === "Enter" && store.selected && !store.editing) store.setEditing(store.selected);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [store]);
	if (!doc || !page) return null;
	const size = pageSize(doc.paper, doc.ori);
	const els = [...page.elements].filter((e) => !e.hidden).sort((a, b) => a.z - b.z);
	const startDrag = (e, el, mode) => {
		if (el.locked || store.editing === el.id) return;
		e.stopPropagation();
		e.preventDefault();
		store.select(el.id);
		store.snapshot();
		const pageEl = wrap.current?.querySelector("[data-page]");
		if (!pageEl) return;
		const r = pageEl.getBoundingClientRect();
		const mmX = (e.clientX - r.left) / r.width * size.w;
		const mmY = (e.clientY - r.top) / r.height * size.h;
		setDrag({
			id: el.id,
			mode,
			sx: mmX,
			sy: mmY,
			ox: el.x,
			oy: el.y,
			ow: el.w,
			oh: el.h
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrap,
		className: "checker flex min-h-0 flex-1 items-start justify-center overflow-auto p-8",
		onPointerDown: () => {
			store.select(null);
			store.setEditing(null);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: { zoom: store.zoom },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-page": true,
				className: "page-shadow relative overflow-hidden bg-surface",
				style: {
					width: `${size.w}mm`,
					height: `${size.h}mm`
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
					id: page.frame,
					color: doc.color
				}), els.map((el) => {
					const on = store.selected === el.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("absolute", on && "z-50 ring-2 ring-primary", el.locked && "pointer-events-none"),
						style: {
							left: `${el.x}mm`,
							top: `${el.y}mm`,
							width: `${el.w}mm`,
							height: `${el.h}mm`,
							transform: el.rot ? `rotate(${el.rot}deg)` : void 0
						},
						onPointerDown: (e) => {
							e.stopPropagation();
							if (store.selected === el.id && !store.editing) startDrag(e, el, "move");
							else store.select(el.id);
						},
						onDoubleClick: (e) => {
							e.stopPropagation();
							store.setEditing(el.id);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ElementView, {
							el,
							editing: store.editing === el.id,
							onChangeText: (p) => store.updateEl(el.id, p, true)
						}), on && !store.editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "absolute -right-1 -bottom-1 size-3 rounded-sm border border-fg bg-surface",
							onPointerDown: (e) => startDrag(e, el, "resize"),
							"aria-label": "resize"
						})]
					}, el.id);
				})]
			})
		})
	});
}
function Inspector() {
	const store = useStudio();
	const el = store.page()?.elements.find((e) => e.id === store.selected);
	if (!el) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "hidden w-72 shrink-0 flex-col border-l border-border bg-surface p-4 md:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-extrabold",
				children: "แผงปรับแต่ง"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-relaxed text-muted",
				children: "คลิกชิ้นงานบนหน้ากระดาษเพื่อแก้แบบเรียลไทม์ — ดับเบิลคลิกเพื่อพิมพ์ตรง ๆ ลากเพื่อย้าย มุมล่างขวาเพื่อย่อขยาย"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageMeta, {})
		]
	});
	const set = (p, hist = true) => store.updateEl(el.id, p, hist);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex w-72 shrink-0 flex-col border-l border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
				className: "text-sm",
				children: "แก้ชิ้นงาน"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-bg px-2 py-0.5 text-[10px] font-bold uppercase text-muted",
				children: el.type
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 space-y-3 overflow-y-auto p-3 text-xs",
			children: [
				(el.type === "text" || el.type === "step" || el.type === "box" || el.type === "signature" || el.type === "checklist") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ข้อความ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "inp",
						value: el.text ?? "",
						onChange: (e) => set({ text: e.target.value }, false)
					})
				}), (el.type === "step" || el.type === "box") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "รายละเอียด",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "inp min-h-16",
						value: el.desc ?? "",
						onChange: (e) => set({ desc: e.target.value }, false)
					})
				})] }),
				el.type === "step" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "ลำดับ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								type: "number",
								value: el.num ?? 1,
								onChange: (e) => set({ num: +e.target.value }, false)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "นาที",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								value: el.time ?? "",
								onChange: (e) => set({ time: e.target.value }, false)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "คน",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "inp",
								value: el.ppl ?? "",
								onChange: (e) => set({ ppl: e.target.value }, false)
							})
						})
					]
				}),
				(el.type === "image" || el.type === "step") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "รูปภาพ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							const r = new FileReader();
							r.onload = () => set({ src: String(r.result) }, true);
							r.readAsDataURL(f);
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ฟอนต์",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "inp",
						value: el.font ?? "Noto Sans Thai",
						onChange: (e) => set({ font: e.target.value }),
						children: FONTS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `ขนาดตัวอักษร ${el.fontSize ?? 12}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 8,
						max: 48,
						value: el.fontSize ?? 12,
						onChange: (e) => set({ fontSize: +e.target.value }, false)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "สีตัวอักษร",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Colors, {
						value: el.color ?? "#1A1714",
						onChange: (c) => set({ color: c }, false)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "สีพื้น",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Colors, {
						value: el.fill ?? "#ffffff",
						onChange: (c) => set({ fill: c }, false)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "สีเส้น",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Colors, {
						value: el.stroke ?? "#0E6B66",
						onChange: (c) => set({ stroke: c }, false)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "กว้าง (มม.)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "inp",
							type: "number",
							value: el.w,
							onChange: (e) => set({ w: +e.target.value }, false)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "สูง (มม.)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "inp",
							type: "number",
							value: el.h,
							onChange: (e) => set({ h: +e.target.value }, false)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1.5 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => store.duplicateEl(el.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), " ทำซ้ำ"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => store.bring(el.id, "front"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-3.5" }), " หน้า"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => store.bring(el.id, "back"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5" }), " หลัง"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => set({ locked: !el.locked }),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }),
								" ",
								el.locked ? "ปลดล็อก" : "ล็อก"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "danger",
							onClick: () => store.removeEl(el.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " ลบ"]
						})
					]
				})
			]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block font-bold text-muted",
			children: label
		}), children]
	});
}
function Colors({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-1",
		children: [PRESET_COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => onChange(c),
			className: "size-5 rounded-full border border-border",
			style: {
				background: c,
				outline: value === c ? "2px solid #1A1714" : void 0
			}
		}, c)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "color",
			value,
			onChange: (e) => onChange(e.target.value),
			className: "h-6 w-7"
		})]
	});
}
function PageMeta() {
	const store = useStudio();
	const doc = store.doc();
	if (!doc) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 space-y-2 border-t border-border pt-4 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "ข้อมูลเอกสาร" }), [
			["title", "ชื่อเอกสาร"],
			["sub", "คำอธิบาย"],
			["docNo", "เลขที่"],
			["dept", "แผนก"]
		].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: l
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "inp mt-0.5",
				value: doc[k],
				onChange: (e) => store.patchDoc({ [k]: e.target.value }, false)
			})]
		}, k))]
	});
}
var TABS = [
	{
		id: "tpl",
		label: "เทมเพลต",
		icon: LayoutTemplate
	},
	{
		id: "el",
		label: "ชิ้นงาน",
		icon: Plus
	},
	{
		id: "deco",
		label: "ตกแต่ง",
		icon: Sparkles
	}
];
function Sidebar() {
	const [tab, setTab] = (0, import_react.useState)("tpl");
	const store = useStudio();
	const doc = store.doc();
	const page = store.page();
	if (!doc || !page) return null;
	const add = (type, extra) => {
		store.addEl(defaultEl(type, extra));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex w-64 shrink-0 flex-col border-r border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 border-b border-border",
			children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setTab(t.id),
				className: cn("flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold", tab === t.id ? "bg-bg text-fg" : "text-muted hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-4" }), t.label]
			}, t.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto p-3",
			children: [
				tab === "tpl" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [FRAMES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => store.setFrame(f.id),
						className: cn("overflow-hidden rounded-xl border text-left", page.frame === f.id ? "border-primary ring-2 ring-primary/40" : "border-border"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-14",
							style: { background: f.thumb }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-2 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold",
								children: f.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-muted",
								children: f.hint
							})]
						})]
					}, f.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-2 mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-1 text-[11px] font-bold text-muted",
							children: "สีหลักของกรอบ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1.5",
							children: [PRESET_COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => store.patchDoc({ color: c }),
								className: cn("size-6 rounded-full border", doc.color === c ? "border-fg" : "border-border"),
								style: { background: c }
							}, c)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								value: doc.color,
								onChange: (e) => store.patchDoc({ color: e.target.value }, false),
								className: "h-6 w-8 cursor-pointer rounded border border-border"
							})]
						})]
					})]
				}),
				tab === "el" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						{
							t: "text",
							l: "ข้อความ",
							i: Type
						},
						{
							t: "step",
							l: "ขั้นตอน",
							i: ListOrdered
						},
						{
							t: "image",
							l: "รูปภาพ",
							i: ImagePlus
						},
						{
							t: "shape",
							l: "รูปทรง",
							i: Shapes
						},
						{
							t: "box",
							l: "กล่องข้อความ",
							i: Square
						},
						{
							t: "checklist",
							l: "เช็กลิสต์",
							i: SquareCheckBig
						},
						{
							t: "signature",
							l: "ลายเซ็น",
							i: PenLine
						},
						{
							t: "box",
							l: "ข้อควรระวัง",
							i: TriangleAlert,
							extra: {
								text: "ข้อควรระวัง",
								fill: "#FFF4E5",
								stroke: "#C45C26"
							}
						}
					].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => add(x.t, x.extra),
						className: "flex flex-col items-center gap-1 rounded-xl border border-border px-2 py-3 text-xs font-semibold hover:bg-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(x.i, { className: "size-5 text-accent" }), x.l]
					}, x.l))
				}),
				tab === "deco" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: STICKERS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						title: s.name,
						onClick: () => add("sticker", {
							sticker: s.id,
							color: doc.color
						}),
						className: "flex aspect-square items-center justify-center rounded-xl border border-border p-2 text-accent hover:bg-bg",
						dangerouslySetInnerHTML: { __html: s.svg }
					}, s.id))
				})
			]
		})]
	});
}
function Editor() {
	const store = useStudio();
	const doc = store.doc();
	const [mobile, setMobile] = (0, import_react.useState)(null);
	if (!doc) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "no-print flex items-center gap-1 overflow-x-auto border-b border-border bg-surface px-2 py-2 md:gap-2 md:px-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => store.closeDoc(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "เอกสาร"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "min-w-24 flex-1 border-0 bg-transparent text-sm font-extrabold outline-none md:max-w-md md:text-base",
					value: doc.title,
					onChange: (e) => store.patchDoc({ title: e.target.value }, false)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "lg:hidden",
					onClick: () => setMobile(mobile === "side" ? null : "side"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shapes, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "lg:hidden",
					onClick: () => setMobile(mobile === "insp" ? null : "insp"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelRight, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => store.undo(),
					title: "Undo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => store.redo(),
					title: "Redo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => store.setZoom(store.zoom - .1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "w-10 text-center text-xs font-bold",
					children: [Math.round(store.zoom * 100), "%"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => store.setZoom(store.zoom + .1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => store.addPage(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: doc.pages.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => store.setPage(i),
						className: `size-7 rounded-lg text-xs font-bold ${store.pageIndex === i ? "bg-primary" : "bg-bg"}`,
						children: i + 1
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => window.print(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "solid",
					onClick: exportPng,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex min-h-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-print hidden md:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
				}),
				mobile === "side" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-print absolute inset-y-0 left-0 z-20 md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-print hidden lg:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inspector, {})
				}),
				mobile === "insp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-print absolute inset-y-0 right-0 z-20 lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inspector, {})
				})
			]
		})]
	});
}
async function exportPng() {
	const el = document.querySelector("[data-page]");
	if (!el) return;
	const canvas = await html2canvas(el, {
		scale: 2,
		useCORS: true,
		backgroundColor: "#ffffff"
	});
	const a = document.createElement("a");
	a.href = canvas.toDataURL("image/png");
	a.download = "WI.png";
	a.click();
}
function Home() {
	const { ready, load, currentId } = useStudio();
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full items-center justify-center bg-bg text-sm font-semibold text-muted",
		children: "กำลังเปิดสตูดิโอ…"
	});
	return currentId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
//#endregion
export { Home as component };
