import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Dashboard } from "@/components/Dashboard";
import { Editor } from "@/components/editor/Editor";
import { useStudio } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { ready, load, currentId } = useStudio();
  useEffect(() => {
    load();
  }, [load]);
  if (!ready) {
    return (
      <div className="flex h-full items-center justify-center bg-bg text-sm font-semibold text-muted">
        กำลังเปิดสตูดิโอ…
      </div>
    );
  }
  return currentId ? <Editor /> : <Dashboard />;
}
