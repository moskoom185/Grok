export const STICKERS: { id: string; name: string; svg: string }[] = [
  {
    id: "star",
    name: "ดาว",
    svg: `<svg viewBox="0 0 64 64"><polygon fill="currentColor" points="32,4 40,24 62,24 44,38 52,58 32,46 12,58 20,38 2,24 24,24"/></svg>`,
  },
  {
    id: "heart",
    name: "หัวใจ",
    svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M32 56s-24-14-24-30a14 14 0 0 1 24-10 14 14 0 0 1 24 10c0 16-24 30-24 30z"/></svg>`,
  },
  {
    id: "leaf",
    name: "ใบไม้",
    svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M12 52 C12 20 44 8 56 8 56 28 40 56 12 52Z"/><path fill="none" stroke="#fff" stroke-width="2" d="M20 44 C28 32 40 20 52 14"/></svg>`,
  },
  {
    id: "flower",
    name: "ดอกไม้",
    svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="18" r="10" fill="currentColor"/><circle cx="18" cy="28" r="10" fill="currentColor"/><circle cx="46" cy="28" r="10" fill="currentColor"/><circle cx="22" cy="46" r="10" fill="currentColor"/><circle cx="42" cy="46" r="10" fill="currentColor"/><circle cx="32" cy="32" r="8" fill="#F2C14E"/></svg>`,
  },
  {
    id: "badge",
    name: "ป้าย",
    svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="currentColor"/><circle cx="32" cy="32" r="20" fill="none" stroke="#fff" stroke-width="2"/></svg>`,
  },
  {
    id: "warn",
    name: "ระวัง",
    svg: `<svg viewBox="0 0 64 64"><polygon fill="#E0A800" points="32,6 60,56 4,56"/><rect x="29" y="24" width="6" height="18" fill="#1A1714"/><rect x="29" y="46" width="6" height="6" fill="#1A1714"/></svg>`,
  },
  {
    id: "check",
    name: "ถูก",
    svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28" fill="#2E7D4F"/><path d="M18 33 l10 10 18-20" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/></svg>`,
  },
  {
    id: "gear",
    name: "เฟือง",
    svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="12" fill="none" stroke="currentColor" stroke-width="6"/><g fill="currentColor">${[0,45,90,135,180,225,270,315].map((a) => `<rect x="29" y="2" width="6" height="14" transform="rotate(${a} 32 32)"/>`).join("")}</g></svg>`,
  },
  {
    id: "clip",
    name: "คลิปบอร์ด",
    svg: `<svg viewBox="0 0 64 64"><rect x="12" y="10" width="40" height="48" rx="4" fill="currentColor"/><rect x="18" y="18" width="28" height="6" fill="#fff"/><rect x="18" y="28" width="28" height="4" fill="#fff" opacity=".7"/><rect x="18" y="36" width="20" height="4" fill="#fff" opacity=".7"/></svg>`,
  },
  {
    id: "tape",
    name: "เทป",
    svg: `<svg viewBox="0 0 64 24"><rect x="0" y="4" width="64" height="16" fill="currentColor" opacity=".75" transform="rotate(-8 32 12)"/></svg>`,
  },
  {
    id: "arrow",
    name: "ลูกศร",
    svg: `<svg viewBox="0 0 64 64"><path d="M8 32 H44 L32 20 M44 32 L32 44" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  },
  {
    id: "spark",
    name: "ประกาย",
    svg: `<svg viewBox="0 0 64 64"><path fill="currentColor" d="M32 2 L36 24 L58 28 L36 32 L32 54 L28 32 L6 28 L28 24 Z"/></svg>`,
  },
  {
    id: "cloud",
    name: "เมฆ",
    svg: `<svg viewBox="0 0 64 40"><ellipse cx="24" cy="24" rx="16" ry="12" fill="currentColor"/><ellipse cx="40" cy="22" rx="14" ry="12" fill="currentColor"/><ellipse cx="32" cy="16" rx="12" ry="10" fill="currentColor"/></svg>`,
  },
  {
    id: "pin",
    name: "หมุด",
    svg: `<svg viewBox="0 0 64 64"><circle cx="32" cy="20" r="14" fill="currentColor"/><rect x="29" y="32" width="6" height="26" fill="currentColor"/></svg>`,
  },
  {
    id: "dotgrid",
    name: "จุด",
    svg: `<svg viewBox="0 0 40 40">${[8,20,32].flatMap((x) => [8,20,32].map((y) => `<circle cx="${x}" cy="${y}" r="3" fill="currentColor"/>`)).join("")}</svg>`,
  },
];
