import type { CSSProperties, ReactNode } from "react";

export interface FrameDef {
  id: string;
  name: string;
  hint: string;
  thumb: string;
  bg: string;
}

export const FRAMES: FrameDef[] = [
  { id: "plain", name: "กระดาษขาว", hint: "ไม่มีกรอบ", thumb: "#FFFFFF", bg: "#FFFFFF" },
  { id: "wi-teal", name: "WI มืออาชีพ", hint: "หัวเข้ม มุมโค้ง", thumb: "#0E6B66", bg: "#F4FAF9" },
  { id: "factory", name: "โรงงานเหลือง", hint: "หัวโค้งมน", thumb: "#E0A800", bg: "#FFFEFA" },
  { id: "grid12", name: "12 ขั้นตอน", hint: "กริดการ์ด", thumb: "#148C8A", bg: "#F2FBFA" },
  { id: "elegant", name: "กรอบหรู", hint: "ลายเส้นอ่อน", thumb: "#E8D5C4", bg: "#FBF6F0" },
  { id: "wave", name: "คลื่นธุรกิจ", hint: "โค้งน้ำเงิน", thumb: "#1D4E89", bg: "#F5F8FC" },
  { id: "floral", name: "ดอกไม้", hint: "มุมดอก", thumb: "#E8A0A0", bg: "#FFFCF8" },
  { id: "botanical", name: "ใบไม้", hint: "กรอบเขียว", thumb: "#3E6B4F", bg: "#F7FBF6" },
  { id: "memphis", name: "เมมฟิส", hint: "รูปทรงสีสด", thumb: "#F2C14E", bg: "#FFFDF7" },
  { id: "dark", name: "ปกเข้ม", hint: "หัวดำทอง", thumb: "#16120E", bg: "#1A1714" },
  { id: "cyber", name: "นีออน", hint: "มุมเรืองแสง", thumb: "#2A1650", bg: "#12081F" },
  { id: "parchment", name: "โบราณ", hint: "กระดาษเก่า", thumb: "#C9B48A", bg: "#F3E6C8" },
  { id: "school", name: "สมุดนักเรียน", hint: "ตารางฟ้า", thumb: "#7EC8E3", bg: "#F4FBFF" },
  { id: "splash", name: "ศิลปะ", hint: "สีกระเด็น", thumb: "#5B8DEF", bg: "#FFFFFF" },
  { id: "festive", name: "เทศกาล", hint: "แดงทอง", thumb: "#C81E1E", bg: "#FFF8F2" },
  { id: "notebook", name: "สมุดปกอ่อน", hint: "เส้นบรรทัด", thumb: "#F2D0A4", bg: "#FFF9EF" },
];

function C({ children }: { color?: string; children: ReactNode }) {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 210 297"
      preserveAspectRatio="none"
      aria-hidden
    >
      {children}
    </svg>
  );
}

export function PageFrame({ id, color }: { id: string; color: string }) {
  const k = color;
  switch (id) {
    case "wi-teal":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F4FAF9" />
          <path d="M0 0 H210 V52 Q168 78 120 58 T0 70 Z" fill={k} />
          <circle cx="198" cy="18" r="28" fill="#ffffff22" />
          <circle cx="186" cy="8" r="10" fill="#ffffff18" />
          <rect x="8" y="8" width="194" height="281" rx="10" fill="none" stroke={k} strokeWidth="1.2" opacity="0.35" />
        </C>
      );
    case "factory":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFFEFA" />
          <path d="M0 0 H210 V38 Q105 58 0 38 Z" fill={k} />
          <circle cx="200" cy="-4" r="36" fill="#ffffff33" />
          <rect x="6" y="6" width="198" height="285" rx="4" fill="none" stroke={k} strokeWidth="1.4" />
        </C>
      );
    case "grid12":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F2FBFA" />
          <path d="M210 0 L210 44 L150 0 Z" fill={k} opacity="0.9" />
          <circle cx="12" cy="16" r="10" fill={k} />
          <rect x="7" y="7" width="196" height="283" rx="12" fill="none" stroke={k} strokeWidth="1.6" />
        </C>
      );
    case "elegant":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FBF6F0" />
          <rect x="8" y="8" width="194" height="281" fill="none" stroke={k} strokeWidth="0.6" />
          <rect x="11" y="11" width="188" height="275" fill="none" stroke={k} strokeWidth="0.35" />
          <path d="M20 20 C28 12, 40 12, 48 20" fill="none" stroke={k} strokeWidth="0.7" />
          <path d="M190 20 C182 12, 170 12, 162 20" fill="none" stroke={k} strokeWidth="0.7" />
          <path d="M20 277 C28 285, 40 285, 48 277" fill="none" stroke={k} strokeWidth="0.7" />
          <path d="M190 277 C182 285, 170 285, 162 277" fill="none" stroke={k} strokeWidth="0.7" />
        </C>
      );
    case "wave":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F5F8FC" />
          <path d="M0 0 H78 C110 40 40 90 0 130 Z" fill={k} />
          <path d="M210 297 H132 C100 250 170 210 210 170 Z" fill={k} opacity="0.85" />
          <circle cx="42" cy="70" r="22" fill="#ffffff33" />
          <circle cx="42" cy="70" r="12" fill="#ffffff22" />
        </C>
      );
    case "floral":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFFCF8" />
          <g fill={k} opacity="0.55">
            <circle cx="18" cy="22" r="8" />
            <circle cx="28" cy="16" r="5" />
            <circle cx="30" cy="28" r="6" />
            <circle cx="192" cy="24" r="9" />
            <circle cx="180" cy="16" r="5" />
            <circle cx="184" cy="34" r="6" />
            <circle cx="20" cy="276" r="8" />
            <circle cx="32" cy="282" r="5" />
            <circle cx="190" cy="274" r="9" />
            <circle cx="178" cy="282" r="6" />
          </g>
          <rect x="14" y="18" width="182" height="261" rx="6" fill="none" stroke={k} strokeWidth="0.8" opacity="0.4" />
        </C>
      );
    case "botanical":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F7FBF6" />
          <g fill="none" stroke={k} strokeWidth="1.1" opacity="0.7">
            <path d="M8 40 C30 10, 60 20, 40 50 C20 70, 10 90, 24 110" />
            <path d="M202 250 C180 280, 150 270, 170 240 C188 220, 200 200, 186 180" />
          </g>
          <ellipse cx="28" cy="58" rx="10" ry="5" fill={k} opacity="0.35" transform="rotate(-30 28 58)" />
          <ellipse cx="182" cy="232" rx="12" ry="5" fill={k} opacity="0.35" transform="rotate(40 182 232)" />
          <rect x="10" y="10" width="190" height="277" rx="2" fill="none" stroke={k} strokeWidth="1" opacity="0.3" />
        </C>
      );
    case "memphis":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFFDF7" />
          <circle cx="18" cy="20" r="16" fill={k} opacity="0.85" />
          <rect x="170" y="-8" width="50" height="50" rx="18" fill="#7C5CFC" />
          <path d="M0 250 L40 297 H0 Z" fill="#FF6B9D" />
          <path d="M160 8 Q190 30 170 50" fill="none" stroke="#7C5CFC" strokeWidth="6" />
          <rect x="12" y="16" width="186" height="265" fill="none" stroke="#1A1714" strokeWidth="1.2" />
        </C>
      );
    case "dark":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#1A1714" />
          <rect x="10" y="10" width="190" height="277" fill="none" stroke={k} strokeWidth="0.8" />
          <circle cx="105" cy="40" r="22" fill="none" stroke={k} strokeWidth="0.7" />
        </C>
      );
    case "cyber":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#12081F" />
          <rect x="8" y="8" width="194" height="281" fill="none" stroke="#C77DFF" strokeWidth="1.4" />
          <rect x="12" y="12" width="186" height="273" fill="none" stroke="#7B2CBF" strokeWidth="0.5" />
          <circle cx="18" cy="18" r="3" fill="#E0A800" />
          <circle cx="192" cy="18" r="3" fill="#E0A800" />
          <circle cx="18" cy="279" r="3" fill="#E0A800" />
          <circle cx="192" cy="279" r="3" fill="#E0A800" />
        </C>
      );
    case "parchment":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F3E6C8" />
          <rect x="9" y="9" width="192" height="279" fill="none" stroke="#8A6A32" strokeWidth="2.2" />
          <rect x="13" y="13" width="184" height="271" fill="none" stroke="#8A6A32" strokeWidth="0.6" />
        </C>
      );
    case "school":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#F4FBFF" />
          <rect x="0" y="0" width="210" height="18" fill="#7EC8E3" />
          {Array.from({ length: 26 }).map((_, i) => (
            <line
              key={i}
              x1="16"
              x2="198"
              y1={28 + i * 10}
              y2={28 + i * 10}
              stroke="#BFE4F2"
              strokeWidth="0.4"
            />
          ))}
          <line x1="28" y1="18" x2="28" y2="290" stroke="#F2A0A0" strokeWidth="0.6" />
        </C>
      );
    case "splash":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFFFFF" />
          <circle cx="20" cy="16" r="14" fill="#5B8DEF" />
          <circle cx="38" cy="10" r="8" fill="#FF6B9D" />
          <circle cx="190" cy="20" r="12" fill="#F2C14E" />
          <circle cx="18" cy="280" r="16" fill="#7C5CFC" />
          <circle cx="200" cy="270" r="20" fill="#5B8DEF" opacity="0.7" />
        </C>
      );
    case "festive":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFF8F2" />
          <rect width="210" height="36" fill="#C81E1E" />
          <rect y="261" width="210" height="36" fill="#C81E1E" />
          <circle cx="24" cy="18" r="8" fill="#E0A800" />
          <circle cx="186" cy="18" r="8" fill="#E0A800" />
        </C>
      );
    case "notebook":
      return (
        <C color={k}>
          <rect width="210" height="297" fill="#FFF9EF" />
          <rect x="0" y="0" width="14" height="297" fill="#E8C48A" />
          {Array.from({ length: 8 }).map((_, i) => (
            <circle key={i} cx="7" cy={24 + i * 34} r="3.2" fill="#FFF9EF" />
          ))}
        </C>
      );
    default:
      return (
        <div
          className="pointer-events-none absolute inset-0"
          style={{ background: "#fff" } as CSSProperties}
        />
      );
  }
}
