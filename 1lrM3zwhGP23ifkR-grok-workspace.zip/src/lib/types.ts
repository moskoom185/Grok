export type Paper = "A4" | "A5" | "Letter";
export type Ori = "p" | "l";
export type ElType =
  | "text"
  | "image"
  | "shape"
  | "icon"
  | "step"
  | "box"
  | "line"
  | "sticker"
  | "signature"
  | "checklist";

export type ShapeKind = "rect" | "round" | "ellipse" | "diamond" | "triangle";

export interface CanvasEl {
  id: string;
  type: ElType;
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
  rot?: number;
  locked?: boolean;
  hidden?: boolean;
  fill?: string;
  stroke?: string;
  strokeW?: number;
  radius?: number;
  opacity?: number;
  font?: string;
  fontSize?: number;
  fontWeight?: number;
  color?: string;
  align?: "left" | "center" | "right";
  text?: string;
  desc?: string;
  src?: string;
  icon?: string;
  sticker?: string;
  shape?: ShapeKind;
  num?: number;
  time?: string;
  ppl?: string;
  items?: string[];
}

export interface Page {
  id: string;
  frame: string;
  bg: string;
  elements: CanvasEl[];
}

export interface Doc {
  id: string;
  title: string;
  sub: string;
  docNo: string;
  rev: string;
  date: string;
  dept: string;
  paper: Paper;
  ori: Ori;
  color: string;
  pages: Page[];
  updated: number;
}

export const PAPER: Record<Paper, [number, number]> = {
  A4: [210, 297],
  A5: [148, 210],
  Letter: [216, 279],
};

export function pageSize(paper: Paper, ori: Ori) {
  const [a, b] = PAPER[paper];
  return ori === "l" ? { w: b, h: a } : { w: a, h: b };
}

export const FONTS = [
  "Noto Sans Thai",
  "Sarabun",
  "Prompt",
  "Kanit",
  "Mitr",
  "Playfair Display",
  "Be Vietnam Pro",
];

export const PRESET_COLORS = [
  "#0E6B66",
  "#E0A800",
  "#1A1714",
  "#C45C26",
  "#3D5A80",
  "#7B2D8E",
  "#C81E1E",
  "#2E7D4F",
  "#FFFFFF",
  "#F6F0E4",
  "#0B1F3A",
  "#FF6B9D",
];
