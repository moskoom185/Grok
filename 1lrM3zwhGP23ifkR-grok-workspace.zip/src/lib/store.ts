import { create } from "zustand";
import { FONTS, type CanvasEl, type Doc, type ElType, type Page, pageSize, type ShapeKind } from "@/lib/types";
import { uid } from "@/lib/utils";

const KEY = "wi-studio-v1";

function today() {
  return new Date().toISOString().slice(0, 10);
}

function sampleSteps(): CanvasEl[] {
  const titles = [
    ["ตรวจสอบพื้นที่", "ดูความเรียบร้อยและความปลอดภัยก่อนเริ่มงาน"],
    ["สวม PPE", "หมวก แว่น ถุงมือ รองเท้าเซฟตี้"],
    ["ปิดแหล่งพลังงาน", "Lockout-Tagout ตามขั้นตอน"],
    ["ปฏิบัติงาน", "ทำตามคู่มือผู้ผลิตทีละขั้น"],
  ];
  return titles.map((t, i) => ({
    id: uid(),
    type: "step" as const,
    x: 12 + (i % 2) * 94,
    y: 78 + Math.floor(i / 2) * 72,
    w: 90,
    h: 66,
    z: 10 + i,
    num: i + 1,
    text: t[0],
    desc: t[1],
    time: "5",
    ppl: "1",
    fill: "#ffffff",
    stroke: "#0E6B66",
    radius: 8,
    font: "Noto Sans Thai",
    fontSize: 11,
    color: "#1A1714",
  }));
}

export function seedPage(frame: string, color: string): Page {
  const dark = frame === "dark" || frame === "cyber";
  const ink = dark ? "#F6F0E4" : "#1A1714";
  const els: CanvasEl[] = [
    {
      id: uid(),
      type: "text",
      x: 14,
      y: frame === "factory" || frame === "wi-teal" || frame === "festive" ? 8 : 16,
      w: 130,
      h: 22,
      z: 20,
      text: "WORK INSTRUCTION",
      font: "Prompt",
      fontSize: 16,
      fontWeight: 800,
      color: frame === "plain" || frame === "elegant" || frame === "floral" ? color : "#FFFFFF",
      align: "left",
    },
    {
      id: uid(),
      type: "text",
      x: 14,
      y: frame === "factory" || frame === "wi-teal" || frame === "festive" ? 24 : 32,
      w: 130,
      h: 12,
      z: 21,
      text: "คู่มือขั้นตอนการทำงาน",
      font: "Noto Sans Thai",
      fontSize: 9,
      color: frame === "plain" || frame === "elegant" || frame === "floral" ? ink : "#FFFFFFCC",
    },
    {
      id: uid(),
      type: "box",
      x: 12,
      y: 58,
      w: 186,
      h: 16,
      z: 5,
      text: "เลขที่ WI-001  ·  Rev 00  ·  แผนก Engineering",
      fill: dark ? "#ffffff14" : "#ffffff",
      stroke: color,
      radius: 6,
      fontSize: 8,
      color: ink,
      font: "Noto Sans Thai",
    },
    ...sampleSteps(),
    {
      id: uid(),
      type: "box",
      x: 12,
      y: 228,
      w: 90,
      h: 36,
      z: 8,
      text: "ข้อควรระวัง",
      desc: "ตัดไฟก่อนซ่อม · ระวังของมีคม",
      fill: "#FFF4E5",
      stroke: "#C45C26",
      radius: 8,
      fontSize: 9,
      fontWeight: 700,
      color: "#8A3B12",
      font: "Noto Sans Thai",
    },
    {
      id: uid(),
      type: "box",
      x: 108,
      y: 228,
      w: 90,
      h: 36,
      z: 8,
      text: "หมายเหตุ",
      desc: "อ้างอิงคู่มือผู้ผลิต",
      fill: "#EAF4FF",
      stroke: "#3D5A80",
      radius: 8,
      fontSize: 9,
      fontWeight: 700,
      color: "#1E3A5F",
      font: "Noto Sans Thai",
    },
    {
      id: uid(),
      type: "signature",
      x: 12,
      y: 268,
      w: 186,
      h: 22,
      z: 9,
      text: "ผู้จัดทำ / ผู้ตรวจสอบ / ผู้อนุมัติ",
      fontSize: 8,
      color: ink,
      font: "Noto Sans Thai",
      fill: dark ? "#ffffff10" : "#ffffff",
      stroke: color,
      radius: 6,
    },
  ];
  return { id: uid(), frame, bg: dark ? "#1A1714" : "#FFFFFF", elements: els };
}

export function blankDoc(): Doc {
  return {
    id: "d_" + uid(),
    title: "งานบำรุงรักษาเครื่องจักร",
    sub: "คู่มือขั้นตอนการทำงาน",
    docNo: "WI-001",
    rev: "00",
    date: today(),
    dept: "Engineering",
    paper: "A4",
    ori: "p",
    color: "#0E6B66",
    pages: [seedPage("wi-teal", "#0E6B66")],
    updated: Date.now(),
  };
}

type Hist = { past: string[]; future: string[] };

interface Store {
  docs: Doc[];
  currentId: string | null;
  pageIndex: number;
  selected: string | null;
  editing: string | null;
  zoom: number;
  ready: boolean;
  hist: Hist;
  load: () => void;
  persist: () => void;
  newDoc: (frame?: string) => void;
  openDoc: (id: string) => void;
  deleteDoc: (id: string) => void;
  closeDoc: () => void;
  doc: () => Doc | null;
  page: () => Page | null;
  patchDoc: (p: Partial<Doc>, hist?: boolean) => void;
  setFrame: (frame: string) => void;
  select: (id: string | null) => void;
  setEditing: (id: string | null) => void;
  addEl: (partial: Partial<CanvasEl> & { type: ElType }) => string;
  updateEl: (id: string, p: Partial<CanvasEl>, hist?: boolean) => void;
  removeEl: (id: string) => void;
  duplicateEl: (id: string) => void;
  bring: (id: string, dir: "front" | "back") => void;
  undo: () => void;
  redo: () => void;
  snapshot: () => void;
  addPage: () => void;
  setPage: (i: number) => void;
  setZoom: (z: number) => void;
}

function read(): Doc[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Doc[];
  } catch {
    return [];
  }
}

export const useStudio = create<Store>((set, get) => ({
  docs: [],
  currentId: null,
  pageIndex: 0,
  selected: null,
  editing: null,
  zoom: 0.85,
  ready: false,
  hist: { past: [], future: [] },

  load: () => {
    const docs = read();
    set({ docs, ready: true });
  },
  persist: () => {
    localStorage.setItem(KEY, JSON.stringify(get().docs));
  },
  newDoc: (frame = "wi-teal") => {
    const d = blankDoc();
    if (frame !== "wi-teal") {
      d.pages = [seedPage(frame, d.color)];
      d.pages[0].frame = frame;
    }
    set((s) => ({
      docs: [d, ...s.docs],
      currentId: d.id,
      pageIndex: 0,
      selected: null,
      hist: { past: [], future: [] },
    }));
    get().persist();
  },
  openDoc: (id) => set({ currentId: id, pageIndex: 0, selected: null, hist: { past: [], future: [] } }),
  deleteDoc: (id) => {
    set((s) => ({
      docs: s.docs.filter((d) => d.id !== id),
      currentId: s.currentId === id ? null : s.currentId,
    }));
    get().persist();
  },
  closeDoc: () => set({ currentId: null, selected: null, editing: null }),
  doc: () => get().docs.find((d) => d.id === get().currentId) ?? null,
  page: () => {
    const d = get().doc();
    if (!d) return null;
    return d.pages[get().pageIndex] ?? d.pages[0] ?? null;
  },
  patchDoc: (p, hist = true) => {
    if (hist) get().snapshot();
    set((s) => ({
      docs: s.docs.map((d) =>
        d.id === s.currentId ? { ...d, ...p, updated: Date.now() } : d,
      ),
    }));
    get().persist();
  },
  setFrame: (frame) => {
    get().snapshot();
    set((s) => ({
      docs: s.docs.map((d) => {
        if (d.id !== s.currentId) return d;
        const pages = d.pages.map((pg, i) =>
          i === s.pageIndex ? { ...pg, frame } : pg,
        );
        return { ...d, pages, updated: Date.now() };
      }),
    }));
    get().persist();
  },
  select: (id) => set({ selected: id, editing: id ? get().editing : null }),
  setEditing: (id) => set({ editing: id, selected: id ?? get().selected }),
  addEl: (partial) => {
    get().snapshot();
    const id = uid();
    const z =
      (get().page()?.elements.reduce((m, e) => Math.max(m, e.z), 0) ?? 1) + 1;
    const el: CanvasEl = {
      x: 20,
      y: 40,
      w: 60,
      h: 24,
      z,
      font: FONTS[0],
      fontSize: 12,
      color: "#1A1714",
      fill: "#ffffff",
      ...partial,
      id,
      type: partial.type,
    };
    set((s) => ({
      docs: s.docs.map((d) => {
        if (d.id !== s.currentId) return d;
        const pages = d.pages.map((pg, i) =>
          i === s.pageIndex ? { ...pg, elements: [...pg.elements, el] } : pg,
        );
        return { ...d, pages, updated: Date.now() };
      }),
      selected: id,
    }));
    get().persist();
    return id;
  },
  updateEl: (id, p, hist = false) => {
    if (hist) get().snapshot();
    set((s) => ({
      docs: s.docs.map((d) => {
        if (d.id !== s.currentId) return d;
        const pages = d.pages.map((pg, i) =>
          i === s.pageIndex
            ? {
                ...pg,
                elements: pg.elements.map((e) => (e.id === id ? { ...e, ...p } : e)),
              }
            : pg,
        );
        return { ...d, pages, updated: Date.now() };
      }),
    }));
    get().persist();
  },
  removeEl: (id) => {
    get().snapshot();
    set((s) => ({
      selected: s.selected === id ? null : s.selected,
      editing: s.editing === id ? null : s.editing,
      docs: s.docs.map((d) => {
        if (d.id !== s.currentId) return d;
        const pages = d.pages.map((pg, i) =>
          i === s.pageIndex
            ? { ...pg, elements: pg.elements.filter((e) => e.id !== id) }
            : pg,
        );
        return { ...d, pages, updated: Date.now() };
      }),
    }));
    get().persist();
  },
  duplicateEl: (id) => {
    const el = get().page()?.elements.find((e) => e.id === id);
    if (!el) return;
    const { id: _omit, ...rest } = el;
    get().addEl({ ...rest, x: el.x + 6, y: el.y + 6 });
  },
  bring: (id, dir) => {
    get().snapshot();
    set((s) => ({
      docs: s.docs.map((d) => {
        if (d.id !== s.currentId) return d;
        const pages = d.pages.map((pg, i) => {
          if (i !== s.pageIndex) return pg;
          const zs = pg.elements.map((e) => e.z);
          const max = Math.max(...zs);
          const min = Math.min(...zs);
          return {
            ...pg,
            elements: pg.elements.map((e) =>
              e.id === id ? { ...e, z: dir === "front" ? max + 1 : min - 1 } : e,
            ),
          };
        });
        return { ...d, pages };
      }),
    }));
    get().persist();
  },
  snapshot: () => {
    const d = get().doc();
    if (!d) return;
    set((s) => ({
      hist: {
        past: [...s.hist.past.slice(-40), JSON.stringify(d)],
        future: [],
      },
    }));
  },
  undo: () => {
    const { hist, currentId } = get();
    if (!hist.past.length || !currentId) return;
    const prev = hist.past[hist.past.length - 1];
    const cur = JSON.stringify(get().doc());
    const doc = JSON.parse(prev) as Doc;
    set((s) => ({
      hist: { past: s.hist.past.slice(0, -1), future: [...s.hist.future, cur] },
      docs: s.docs.map((d) => (d.id === currentId ? doc : d)),
    }));
    get().persist();
  },
  redo: () => {
    const { hist, currentId } = get();
    if (!hist.future.length || !currentId) return;
    const next = hist.future[hist.future.length - 1];
    const cur = JSON.stringify(get().doc());
    const doc = JSON.parse(next) as Doc;
    set((s) => ({
      hist: { past: [...s.hist.past, cur], future: s.hist.future.slice(0, -1) },
      docs: s.docs.map((d) => (d.id === currentId ? doc : d)),
    }));
    get().persist();
  },
  addPage: () => {
    const d = get().doc();
    if (!d) return;
    get().snapshot();
    const pg = seedPage(d.pages[0]?.frame ?? "plain", d.color);
    set((s) => ({
      pageIndex: d.pages.length,
      docs: s.docs.map((x) =>
        x.id === d.id ? { ...x, pages: [...x.pages, pg], updated: Date.now() } : x,
      ),
    }));
    get().persist();
  },
  setPage: (i) => set({ pageIndex: i, selected: null, editing: null }),
  setZoom: (z) => set({ zoom: Math.min(1.8, Math.max(0.35, z)) }),
}));

export function defaultEl(type: ElType, extra?: Partial<CanvasEl>): Partial<CanvasEl> & { type: ElType } {
  const base: Record<string, Partial<CanvasEl>> = {
    text: { w: 80, h: 16, text: "พิมพ์ข้อความ", fontSize: 12 },
    image: { w: 70, h: 50, fill: "#F3ECE0" },
    shape: { w: 40, h: 40, fill: "#0E6B66", shape: "round" as ShapeKind },
    icon: { w: 16, h: 16, icon: "star", color: "#E0A800" },
    step: {
      w: 90,
      h: 64,
      text: "ขั้นตอนใหม่",
      desc: "รายละเอียด…",
      num: 1,
      time: "5",
      ppl: "1",
      stroke: "#0E6B66",
      radius: 8,
    },
    box: {
      w: 90,
      h: 32,
      text: "หัวข้อกล่อง",
      desc: "เนื้อหา",
      fill: "#FFF4E5",
      stroke: "#C45C26",
      radius: 8,
    },
    line: { w: 80, h: 2, fill: "#1A1714" },
    sticker: { w: 22, h: 22, sticker: "star", color: "#E0A800" },
    signature: { w: 186, h: 22, text: "ผู้จัดทำ / วันที่", stroke: "#0E6B66" },
    checklist: {
      w: 90,
      h: 40,
      text: "ตรวจก่อนเริ่มงาน",
      items: ["ข้อ 1", "ข้อ 2", "ข้อ 3"],
      stroke: "#0E6B66",
      radius: 8,
    },
  };
  return { type, ...(base[type] ?? {}), ...extra };
}

void pageSize;
