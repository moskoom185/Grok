import { Button } from "@/components/ui/button";
import { FRAMES } from "@/lib/frames";
import { useStudio } from "@/lib/store";
import { FilePlus, Trash2 } from "lucide-react";

export function Dashboard() {
  const { docs, newDoc, openDoc, deleteDoc } = useStudio();
  return (
    <div className="h-full overflow-y-auto bg-bg">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold tracking-widest text-accent uppercase">WI Studio</p>
            <h1 className="mt-1 text-3xl font-extrabold">สร้างคู่มืองานแบบลากวาง</h1>
            <p className="mt-2 max-w-xl text-sm text-muted">
              จิ้มบนหน้ากระดาษแล้วพิมพ์ได้เลย เลือกกรอบเทมเพลต ใส่รูป ตกแต่ง และส่งออก — เหมือน Canva สำหรับ Work Instruction
            </p>
          </div>
          <Button variant="solid" onClick={() => newDoc("wi-teal")}>
            <FilePlus className="size-4" /> สร้างใหม่
          </Button>
        </div>
        <h2 className="mb-3 text-sm font-extrabold">เริ่มจากเทมเพลต</h2>
        <div className="mb-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {FRAMES.slice(0, 8).map((f) => (
            <button
              key={f.id}
              onClick={() => newDoc(f.id)}
              className="overflow-hidden rounded-2xl border border-border bg-surface text-left hover:border-primary"
            >
              <div className="h-20" style={{ background: f.thumb }} />
              <div className="px-3 py-2">
                <div className="text-sm font-bold">{f.name}</div>
                <div className="text-[11px] text-muted">{f.hint}</div>
              </div>
            </button>
          ))}
        </div>
        <h2 className="mb-3 text-sm font-extrabold">เอกสารของฉัน</h2>
        {docs.length === 0 ? (
          <p className="text-sm text-muted">ยังไม่มีเอกสาร — กดสร้างใหม่หรือเลือกเทมเพลตด้านบน</p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {docs.map((d) => (
              <div
                key={d.id}
                className="flex cursor-pointer flex-col rounded-2xl border border-border bg-surface p-4 hover:border-primary"
                onClick={() => openDoc(d.id)}
              >
                <div className="flex items-start justify-between">
                  <span className="rounded-full bg-bg px-2 py-0.5 text-[11px] font-bold">{d.docNo}</span>
                  <button
                    className="text-muted hover:text-danger"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm("ลบเอกสารนี้?")) deleteDoc(d.id);
                    }}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
                <h3 className="mt-2 font-bold">{d.title}</h3>
                <p className="text-xs text-muted">
                  {d.pages.length} หน้า · {new Date(d.updated).toLocaleString("th-TH")}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
