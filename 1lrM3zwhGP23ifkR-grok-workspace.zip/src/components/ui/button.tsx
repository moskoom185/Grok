import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes } from "react";

export function Button({
  className,
  variant = "ghost",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "ghost" | "solid" | "accent" | "danger";
}) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition disabled:opacity-40",
        variant === "ghost" && "border border-border bg-surface text-fg hover:bg-bg",
        variant === "solid" && "bg-primary text-primary-fg hover:brightness-95",
        variant === "accent" && "bg-accent text-accent-fg hover:brightness-110",
        variant === "danger" && "text-danger hover:bg-bg",
        className,
      )}
      {...props}
    />
  );
}
