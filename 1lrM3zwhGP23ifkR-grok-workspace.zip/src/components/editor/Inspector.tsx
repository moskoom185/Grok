import type { ReactNode } from "react";
import { FONTS, PRESET_COLORS, type CanvasEl } from "@/lib/types";
import { useStudio } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Copy, Lock, Trash2, ChevronUp, ChevronDown } from "lucide-react";

export function Inspector() {
  const store = useStudio();
  const page = store.page();
  const el = page?.elements.find((e) => e.id === store.selected);

  if (!el) {
    return (
      <aside className="hidden w-72 shrink-0 flex-col border-l border-border bg-surface p-4 md:flex">
        <h3 className="text-sm font-extrabold">แผงปรับแต่ง</h3>
        <p className="mt-2 text-xs leading-relaxed text-muted">
          คลิกชิ้นงานบนหน้ากระดาษเพื่อแก้แบบเรียลไทม์ — ดับเบิลคลิกเพื่อพิมพ์ตรง ๆ
          ลากเพื่อย้าย มุมล่างขวาเพื่อย่อขยาย
        </p>
        <PageMeta />
      </aside>
    );
  }

  const set = (p: Partial<CanvasEl>, hist = true) => store.updateEl(el.id, p, hist);

  return (
    <aside className="flex w-72 shrink-0 flex-col border-l border-border bg-surface">
      <div className="flex items-center justify-between border-b border-border px-3 py-2">
        <b className="text-sm">แก้ชิ้นงาน</b>
        <span className="rounded-full bg-bg px-2 py-0.5 text-[10px] font-bold uppercase text-muted">
          {el.type}
        </span>
      </div>
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3 text-xs">
        {(el.type === "text" ||
          el.type === "step" ||
          el.type === "box" ||
          el.type === "signature" ||
          el.type === "checklist") && (
          <>
            <Field label="ข้อความ">
              <input
                className="inp"
                value={el.text ?? ""}
                onChange={(e) => set({ text: e.target.value }, false)}
              />
            </Field>
            {(el.type === "step" || el.type === "box") && (
              <Field label="รายละเอียด">
                <textarea
                  className="inp min-h-16"
                  value={el.desc ?? ""}
                  onChange={(e) => set({ desc: e.target.value }, false)}
                />
              </Field>
            )}
          </>
        )}
        {el.type === "step" && (
          <div className="grid grid-cols-3 gap-2">
            <Field label="ลำดับ">
              <input
                className="inp"
                type="number"
                value={el.num ?? 1}
                onChange={(e) => set({ num: +e.target.value }, false)}
              />
            </Field>
            <Field label="นาที">
              <input
                className="inp"
                value={el.time ?? ""}
                onChange={(e) => set({ time: e.target.value }, false)}
              />
            </Field>
            <Field label="คน">
              <input
                className="inp"
                value={el.ppl ?? ""}
                onChange={(e) => set({ ppl: e.target.value }, false)}
              />
            </Field>
          </div>
        )}
        {(el.type === "image" || el.type === "step") && (
          <Field label="รูปภาพ">
            <input
              type="file"
              accept="image/*"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const r = new FileReader();
                r.onload = () => set({ src: String(r.result) }, true);
                r.readAsDataURL(f);
              }}
            />
          </Field>
        )}
        <Field label="ฟอนต์">
          <select
            className="inp"
            value={el.font ?? "Noto Sans Thai"}
            onChange={(e) => set({ font: e.target.value })}
          >
            {FONTS.map((f) => (
              <option key={f}>{f}</option>
            ))}
          </select>
        </Field>
        <Field label={`ขนาดตัวอักษร ${el.fontSize ?? 12}`}>
          <input
            type="range"
            min={8}
            max={48}
            value={el.fontSize ?? 12}
            onChange={(e) => set({ fontSize: +e.target.value }, false)}
          />
        </Field>
        <Field label="สีตัวอักษร">
          <Colors value={el.color ?? "#1A1714"} onChange={(c) => set({ color: c }, false)} />
        </Field>
        <Field label="สีพื้น">
          <Colors value={el.fill ?? "#ffffff"} onChange={(c) => set({ fill: c }, false)} />
        </Field>
        <Field label="สีเส้น">
          <Colors value={el.stroke ?? "#0E6B66"} onChange={(c) => set({ stroke: c }, false)} />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="กว้าง (มม.)">
            <input
              className="inp"
              type="number"
              value={el.w}
              onChange={(e) => set({ w: +e.target.value }, false)}
            />
          </Field>
          <Field label="สูง (มม.)">
            <input
              className="inp"
              type="number"
              value={el.h}
              onChange={(e) => set({ h: +e.target.value }, false)}
            />
          </Field>
        </div>
        <div className="flex flex-wrap gap-1.5 pt-1">
          <Button onClick={() => store.duplicateEl(el.id)}>
            <Copy className="size-3.5" /> ทำซ้ำ
          </Button>
          <Button onClick={() => store.bring(el.id, "front")}>
            <ChevronUp className="size-3.5" /> หน้า
          </Button>
          <Button onClick={() => store.bring(el.id, "back")}>
            <ChevronDown className="size-3.5" /> หลัง
          </Button>
          <Button onClick={() => set({ locked: !el.locked })}>
            <Lock className="size-3.5" /> {el.locked ? "ปลดล็อก" : "ล็อก"}
          </Button>
          <Button variant="danger" onClick={() => store.removeEl(el.id)}>
            <Trash2 className="size-3.5" /> ลบ
          </Button>
        </div>
      </div>
    </aside>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block font-bold text-muted">{label}</span>
      {children}
    </label>
  );
}

function Colors({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex flex-wrap items-center gap-1">
      {PRESET_COLORS.map((c) => (
        <button
          key={c}
          onClick={() => onChange(c)}
          className="size-5 rounded-full border border-border"
          style={{ background: c, outline: value === c ? "2px solid #1A1714" : undefined }}
        />
      ))}
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-6 w-7" />
    </div>
  );
}

function PageMeta() {
  const store = useStudio();
  const doc = store.doc();
  if (!doc) return null;
  return (
    <div className="mt-6 space-y-2 border-t border-border pt-4 text-xs">
      <b>ข้อมูลเอกสาร</b>
      {(
        [
          ["title", "ชื่อเอกสาร"],
          ["sub", "คำอธิบาย"],
          ["docNo", "เลขที่"],
          ["dept", "แผนก"],
        ] as const
      ).map(([k, l]) => (
        <label key={k} className="block">
          <span className="text-muted">{l}</span>
          <input
            className="inp mt-0.5"
            value={doc[k]}
            onChange={(e) => store.patchDoc({ [k]: e.target.value }, false)}
          />
        </label>
      ))}
    </div>
  );
}
