import { FRAMES } from "@/lib/frames";
import { STICKERS } from "@/lib/stickers";
import { defaultEl, useStudio } from "@/lib/store";
import { PRESET_COLORS } from "@/lib/types";
import { cn } from "@/lib/utils";
import {
  AlertTriangle,
  CheckSquare,
  ImagePlus,
  LayoutTemplate,
  ListOrdered,
  PenLine,
  Plus,
  Shapes,
  Sparkles,
  Square,
  Type,
} from "lucide-react";
import { useState } from "react";

const TABS = [
  { id: "tpl", label: "เทมเพลต", icon: LayoutTemplate },
  { id: "el", label: "ชิ้นงาน", icon: Plus },
  { id: "deco", label: "ตกแต่ง", icon: Sparkles },
] as const;

export function Sidebar() {
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("tpl");
  const store = useStudio();
  const doc = store.doc();
  const page = store.page();
  if (!doc || !page) return null;

  const add = (type: Parameters<typeof defaultEl>[0], extra?: Parameters<typeof defaultEl>[1]) => {
    store.addEl(defaultEl(type, extra));
  };

  return (
    <aside className="flex w-64 shrink-0 flex-col border-r border-border bg-surface">
      <div className="grid grid-cols-3 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold",
              tab === t.id ? "bg-bg text-fg" : "text-muted hover:text-fg",
            )}
          >
            <t.icon className="size-4" />
            {t.label}
          </button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto p-3">
        {tab === "tpl" && (
          <div className="grid grid-cols-2 gap-2">
            {FRAMES.map((f) => (
              <button
                key={f.id}
                onClick={() => store.setFrame(f.id)}
                className={cn(
                  "overflow-hidden rounded-xl border text-left",
                  page.frame === f.id ? "border-primary ring-2 ring-primary/40" : "border-border",
                )}
              >
                <div className="h-14" style={{ background: f.thumb }} />
                <div className="px-2 py-1.5">
                  <div className="text-xs font-bold">{f.name}</div>
                  <div className="text-[10px] text-muted">{f.hint}</div>
                </div>
              </button>
            ))}
            <div className="col-span-2 mt-2">
              <div className="mb-1 text-[11px] font-bold text-muted">สีหลักของกรอบ</div>
              <div className="flex flex-wrap gap-1.5">
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => store.patchDoc({ color: c })}
                    className={cn(
                      "size-6 rounded-full border",
                      doc.color === c ? "border-fg" : "border-border",
                    )}
                    style={{ background: c }}
                  />
                ))}
                <input
                  type="color"
                  value={doc.color}
                  onChange={(e) => store.patchDoc({ color: e.target.value }, false)}
                  className="h-6 w-8 cursor-pointer rounded border border-border"
                />
              </div>
            </div>
          </div>
        )}
        {tab === "el" && (
          <div className="grid grid-cols-2 gap-2">
            {[
              { t: "text" as const, l: "ข้อความ", i: Type },
              { t: "step" as const, l: "ขั้นตอน", i: ListOrdered },
              { t: "image" as const, l: "รูปภาพ", i: ImagePlus },
              { t: "shape" as const, l: "รูปทรง", i: Shapes },
              { t: "box" as const, l: "กล่องข้อความ", i: Square },
              { t: "checklist" as const, l: "เช็กลิสต์", i: CheckSquare },
              { t: "signature" as const, l: "ลายเซ็น", i: PenLine },
              { t: "box" as const, l: "ข้อควรระวัง", i: AlertTriangle, extra: { text: "ข้อควรระวัง", fill: "#FFF4E5", stroke: "#C45C26" } },
            ].map((x) => (
              <button
                key={x.l}
                onClick={() => add(x.t, x.extra)}
                className="flex flex-col items-center gap-1 rounded-xl border border-border px-2 py-3 text-xs font-semibold hover:bg-bg"
              >
                <x.i className="size-5 text-accent" />
                {x.l}
              </button>
            ))}
          </div>
        )}
        {tab === "deco" && (
          <div className="grid grid-cols-3 gap-2">
            {STICKERS.map((s) => (
              <button
                key={s.id}
                title={s.name}
                onClick={() => add("sticker", { sticker: s.id, color: doc.color })}
                className="flex aspect-square items-center justify-center rounded-xl border border-border p-2 text-accent hover:bg-bg"
                dangerouslySetInnerHTML={{ __html: s.svg }}
              />
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}
