import type { CSSProperties, FocusEvent } from "react";
import { STICKERS } from "@/lib/stickers";
import type { CanvasEl } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ImageIcon } from "lucide-react";

export function ElementView({
  el,
  editing,
  onChangeText,
}: {
  el: CanvasEl;
  editing: boolean;
  onChangeText: (patch: Partial<CanvasEl>) => void;
}) {
  const font: CSSProperties = {
    fontFamily: el.font ?? "Noto Sans Thai",
    fontSize: `${el.fontSize ?? 11}px`,
    fontWeight: el.fontWeight ?? 500,
    color: el.color ?? "#1A1714",
    textAlign: el.align ?? "left",
    opacity: el.opacity ?? 1,
  };

  const edit = (field: "text" | "desc") =>
    editing
      ? {
          contentEditable: true as const,
          suppressContentEditableWarning: true,
          onBlur: (e: FocusEvent<HTMLElement>) =>
            onChangeText({ [field]: e.currentTarget.innerText }),
          className: "outline-none min-w-[1ch]",
        }
      : {};

  if (el.type === "line") {
    return (
      <div
        className="h-full w-full"
        style={{ background: el.fill ?? "#1A1714", borderRadius: 2 }}
      />
    );
  }

  if (el.type === "shape") {
    const r =
      el.shape === "round"
        ? "999px"
        : el.shape === "ellipse"
          ? "50%"
          : `${el.radius ?? 8}px`;
    if (el.shape === "triangle") {
      return (
        <div
          className="h-full w-full"
          style={{
            clipPath: "polygon(50% 0, 100% 100%, 0 100%)",
            background: el.fill ?? "#0E6B66",
            opacity: el.opacity ?? 1,
          }}
        />
      );
    }
    if (el.shape === "diamond") {
      return (
        <div
          className="h-full w-full"
          style={{
            clipPath: "polygon(50% 0, 100% 50%, 50% 100%, 0 50%)",
            background: el.fill ?? "#0E6B66",
            opacity: el.opacity ?? 1,
          }}
        />
      );
    }
    return (
      <div
        className="h-full w-full"
        style={{
          background: el.fill,
          border: el.stroke ? `${el.strokeW ?? 1}px solid ${el.stroke}` : undefined,
          borderRadius: r,
          opacity: el.opacity ?? 1,
        }}
      />
    );
  }

  if (el.type === "sticker") {
    const s = STICKERS.find((x) => x.id === el.sticker) ?? STICKERS[0];
    return (
      <div
        className="h-full w-full [&_svg]:h-full [&_svg]:w-full"
        style={{ color: el.color ?? "#E0A800" }}
        dangerouslySetInnerHTML={{ __html: s.svg }}
      />
    );
  }

  if (el.type === "image") {
    return el.src ? (
      <img src={el.src} alt="" className="h-full w-full object-cover" draggable={false} />
    ) : (
      <div className="flex h-full w-full items-center justify-center bg-bg text-muted">
        <ImageIcon className="size-8" />
      </div>
    );
  }

  if (el.type === "step") {
    return (
      <div
        className="flex h-full w-full flex-col overflow-hidden"
        style={{
          background: el.fill ?? "#fff",
          border: `1.4px solid ${el.stroke ?? "#0E6B66"}`,
          borderRadius: el.radius ?? 8,
        }}
      >
        <div className="flex items-start gap-1.5 px-1.5 pt-1">
          <span
            className="flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-extrabold text-accent-fg"
            style={{ background: el.stroke ?? "#0E6B66" }}
          >
            {el.num ?? 1}
          </span>
          <div className="min-w-0 flex-1">
            <div {...edit("text")} style={{ ...font, fontWeight: 800, fontSize: 11 }}>
              {el.text}
            </div>
            <div
              {...edit("desc")}
              style={{ ...font, fontWeight: 400, fontSize: 9, opacity: 0.85 }}
            >
              {el.desc}
            </div>
          </div>
        </div>
        <div className="relative mx-1.5 mt-1 min-h-0 flex-1 overflow-hidden rounded bg-bg">
          {el.src ? (
            <img src={el.src} alt="" className="h-full w-full object-cover" draggable={false} />
          ) : (
            <div className="flex h-full items-center justify-center text-muted">
              <ImageIcon className="size-5" />
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2 px-1.5 py-0.5 text-[8px] text-muted">
          <span>{el.time ?? "5"} นาที</span>
          <span>{el.ppl ?? "1"} คน</span>
        </div>
      </div>
    );
  }

  if (el.type === "box" || el.type === "signature" || el.type === "checklist") {
    return (
      <div
        className="flex h-full w-full flex-col overflow-hidden px-2 py-1"
        style={{
          background: el.fill ?? "#fff",
          border: `1.2px solid ${el.stroke ?? "#E5D9C4"}`,
          borderRadius: el.radius ?? 8,
          ...font,
        }}
      >
        <div {...edit("text")} style={{ fontWeight: 800 }}>
          {el.text}
        </div>
        {el.type === "checklist" ? (
          <ul className="mt-0.5 space-y-0.5 text-[9px] font-normal">
            {(el.items ?? []).map((it, i) => (
              <li key={i} className="flex items-center gap-1">
                <span className="inline-block size-2 rounded-sm border border-current" />
                {it}
              </li>
            ))}
          </ul>
        ) : el.desc ? (
          <div {...edit("desc")} className="text-[9px] font-normal opacity-80">
            {el.desc}
          </div>
        ) : el.type === "signature" ? (
          <div className="mt-1 flex flex-1 gap-2">
            {["ผู้จัดทำ", "ผู้ตรวจ", "ผู้อนุมัติ"].map((l) => (
              <div key={l} className="flex-1 border-b border-dashed border-muted text-center text-[8px]">
                {l}
              </div>
            ))}
          </div>
        ) : null}
      </div>
    );
  }

  return (
    <div
      {...edit("text")}
      className={cn("h-full w-full leading-tight", editing && "ring-0")}
      style={font}
    >
      {el.text}
    </div>
  );
}
