import { useState } from "react";
import html2canvas from "html2canvas";
import { Button } from "@/components/ui/button";
import { useStudio } from "@/lib/store";
import {
  ArrowLeft,
  Download,
  PanelRight,
  Plus,
  Printer,
  Redo2,
  Shapes,
  Undo2,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { Canvas } from "./Canvas";
import { Inspector } from "./Inspector";
import { Sidebar } from "./Sidebar";

export function Editor() {
  const store = useStudio();
  const doc = store.doc();
  const [mobile, setMobile] = useState<"side" | "insp" | null>(null);
  if (!doc) return null;

  return (
    <div className="flex h-full flex-col bg-bg text-fg">
      <header className="no-print flex items-center gap-1 overflow-x-auto border-b border-border bg-surface px-2 py-2 md:gap-2 md:px-3">
        <Button onClick={() => store.closeDoc()}>
          <ArrowLeft className="size-4" /> <span className="hidden sm:inline">เอกสาร</span>
        </Button>
        <input
          className="min-w-24 flex-1 border-0 bg-transparent text-sm font-extrabold outline-none md:max-w-md md:text-base"
          value={doc.title}
          onChange={(e) => store.patchDoc({ title: e.target.value }, false)}
        />
        <Button className="lg:hidden" onClick={() => setMobile(mobile === "side" ? null : "side")}>
          <Shapes className="size-4" />
        </Button>
        <Button className="lg:hidden" onClick={() => setMobile(mobile === "insp" ? null : "insp")}>
          <PanelRight className="size-4" />
        </Button>
        <Button onClick={() => store.undo()} title="Undo">
          <Undo2 className="size-4" />
        </Button>
        <Button onClick={() => store.redo()} title="Redo">
          <Redo2 className="size-4" />
        </Button>
        <Button onClick={() => store.setZoom(store.zoom - 0.1)}>
          <ZoomOut className="size-4" />
        </Button>
        <span className="w-10 text-center text-xs font-bold">{Math.round(store.zoom * 100)}%</span>
        <Button onClick={() => store.setZoom(store.zoom + 0.1)}>
          <ZoomIn className="size-4" />
        </Button>
        <Button onClick={() => store.addPage()}>
          <Plus className="size-4" />
        </Button>
        <div className="flex gap-1">
          {doc.pages.map((_, i) => (
            <button
              key={i}
              onClick={() => store.setPage(i)}
              className={`size-7 rounded-lg text-xs font-bold ${
                store.pageIndex === i ? "bg-primary" : "bg-bg"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
        <Button onClick={() => window.print()}>
          <Printer className="size-4" />
        </Button>
        <Button variant="solid" onClick={exportPng}>
          <Download className="size-4" />
        </Button>
      </header>
      <div className="relative flex min-h-0 flex-1">
        <div className="no-print hidden md:flex">
          <Sidebar />
        </div>
        {mobile === "side" && (
          <div className="no-print absolute inset-y-0 left-0 z-20 md:hidden">
            <Sidebar />
          </div>
        )}
        <Canvas />
        <div className="no-print hidden lg:flex">
          <Inspector />
        </div>
        {mobile === "insp" && (
          <div className="no-print absolute inset-y-0 right-0 z-20 lg:hidden">
            <Inspector />
          </div>
        )}
      </div>
    </div>
  );
}
async function exportPng() {
  const el = document.querySelector("[data-page]") as HTMLElement | null;
  if (!el) return;
  const canvas = await html2canvas(el, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
  const a = document.createElement("a");
  a.href = canvas.toDataURL("image/png");
  a.download = "WI.png";
  a.click();
}
