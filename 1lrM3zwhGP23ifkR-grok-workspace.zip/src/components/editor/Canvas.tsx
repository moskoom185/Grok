import { PageFrame } from "@/lib/frames";
import { useStudio } from "@/lib/store";
import { pageSize, type CanvasEl } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useEffect, useRef, useState, type PointerEvent as PE } from "react";
import { ElementView } from "./ElementView";

export function Canvas() {
  const store = useStudio();
  const doc = store.doc();
  const page = store.page();
  const wrap = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{
    id: string;
    mode: "move" | "resize";
    sx: number;
    sy: number;
    ox: number;
    oy: number;
    ow: number;
    oh: number;
  } | null>(null);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (!drag || !doc) return;
      const size = pageSize(doc.paper, doc.ori);
      const pageEl = wrap.current?.querySelector("[data-page]") as HTMLElement | null;
      if (!pageEl) return;
      const r = pageEl.getBoundingClientRect();
      const mmX = ((e.clientX - r.left) / r.width) * size.w;
      const mmY = ((e.clientY - r.top) / r.height) * size.h;
      const dx = mmX - drag.sx;
      const dy = mmY - drag.sy;
      if (drag.mode === "move") {
        store.updateEl(drag.id, {
          x: Math.round((drag.ox + dx) * 10) / 10,
          y: Math.round((drag.oy + dy) * 10) / 10,
        });
      } else {
        store.updateEl(drag.id, {
          w: Math.max(8, Math.round((drag.ow + dx) * 10) / 10),
          h: Math.max(6, Math.round((drag.oh + dy) * 10) / 10),
        });
      }
    };
    const onUp = () => setDrag(null);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [drag, doc, store]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.isContentEditable || t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
      if ((e.metaKey || e.ctrlKey) && e.key === "z") {
        e.preventDefault();
        e.shiftKey ? store.redo() : store.undo();
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "d" && store.selected) {
        e.preventDefault();
        store.duplicateEl(store.selected);
      }
      if ((e.key === "Delete" || e.key === "Backspace") && store.selected && !store.editing) {
        store.removeEl(store.selected);
      }
      if (e.key === "Escape") {
        store.setEditing(null);
        store.select(null);
      }
      if (e.key === "Enter" && store.selected && !store.editing) {
        store.setEditing(store.selected);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [store]);

  if (!doc || !page) return null;
  const size = pageSize(doc.paper, doc.ori);
  const els = [...page.elements].filter((e) => !e.hidden).sort((a, b) => a.z - b.z);

  const startDrag = (e: PE, el: CanvasEl, mode: "move" | "resize") => {
    if (el.locked || store.editing === el.id) return;
    e.stopPropagation();
    e.preventDefault();
    store.select(el.id);
    store.snapshot();
    const pageEl = wrap.current?.querySelector("[data-page]") as HTMLElement | null;
    if (!pageEl) return;
    const r = pageEl.getBoundingClientRect();
    const mmX = ((e.clientX - r.left) / r.width) * size.w;
    const mmY = ((e.clientY - r.top) / r.height) * size.h;
    setDrag({
      id: el.id,
      mode,
      sx: mmX,
      sy: mmY,
      ox: el.x,
      oy: el.y,
      ow: el.w,
      oh: el.h,
    });
  };

  return (
    <div
      ref={wrap}
      className="checker flex min-h-0 flex-1 items-start justify-center overflow-auto p-8"
      onPointerDown={() => {
        store.select(null);
        store.setEditing(null);
      }}
    >
      <div style={{ zoom: store.zoom }}>
        <div
          data-page
          className="page-shadow relative overflow-hidden bg-surface"
          style={{ width: `${size.w}mm`, height: `${size.h}mm` }}
        >
          <PageFrame id={page.frame} color={doc.color} />
          {els.map((el) => {
            const on = store.selected === el.id;
            return (
              <div
                key={el.id}
                className={cn(
                  "absolute",
                  on && "z-50 ring-2 ring-primary",
                  el.locked && "pointer-events-none",
                )}
                style={{
                  left: `${el.x}mm`,
                  top: `${el.y}mm`,
                  width: `${el.w}mm`,
                  height: `${el.h}mm`,
                  transform: el.rot ? `rotate(${el.rot}deg)` : undefined,
                }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  if (store.selected === el.id && !store.editing) {
                    startDrag(e, el, "move");
                  } else {
                    store.select(el.id);
                  }
                }}
                onDoubleClick={(e) => {
                  e.stopPropagation();
                  store.setEditing(el.id);
                }}
              >
                <ElementView
                  el={el}
                  editing={store.editing === el.id}
                  onChangeText={(p) => store.updateEl(el.id, p, true)}
                />
                {on && !store.editing && (
                  <button
                    className="absolute -right-1 -bottom-1 size-3 rounded-sm border border-fg bg-surface"
                    onPointerDown={(e) => startDrag(e, el, "resize")}
                    aria-label="resize"
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
